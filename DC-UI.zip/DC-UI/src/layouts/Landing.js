import React from "react";
import { Outlet } from "react-router-dom";

import Main from "../components/Main";

const Landing = ({ children }) => 
(
  
    <>
      <Main className="gradient-bg-welcome">    
        {children}
        <Outlet />
      </Main>
    </>
  )
;

export default Landing;

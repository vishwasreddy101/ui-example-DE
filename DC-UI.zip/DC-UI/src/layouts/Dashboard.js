import React  from "react";
import { Outlet , useLocation } from "react-router-dom";

import Wrapper from "../components/Wrapper";
import Sidebar from "../components/sidebar/Sidebar";
import Main from "../components/Main";
import Navbar from "../components/navbar/Navbar";
import Content from "../components/Content";
import Footer from "../components/Footer";
import Settings from "../components/Settings";


import dashboardItems  from "../components/sidebar/dashboardItems";

const Dashboard = ({ children }) => {
 
  const {state} = useLocation();

  console.log(state);



  if(state){
      const {id,emailID,roles,page_access,userName} = state;
      localStorage.removeItem('id');
      localStorage.removeItem('emailID');
      localStorage.removeItem('roles');
      localStorage.removeItem('page_access');
      localStorage.removeItem('userName');




      localStorage.setItem('id', id)
      localStorage.setItem('emailID', emailID);
      localStorage.setItem('roles', roles);
      localStorage.setItem('page_access', page_access);
      localStorage.setItem('userName', userName);

      if(dashboardItems){
        for(const item of dashboardItems[0].pages) {
            const indexArray = [];
      
          for(const [index,children] of item.children.entries()){
             
            let roles = localStorage.getItem('page_access').split(',');      
            for(const role of roles ){
      
              if(children.href.search(role) > 0){
                indexArray.push(children);
             };
           }
            
      
           
          }
          if(indexArray.length > 0) {
            item.children = [];
            for(const x of indexArray){
              item.children.push(x);
            }
          }
        }
      
      }
      

  }
  
  return (
  <React.Fragment>
    <Wrapper>
      <Sidebar items={dashboardItems} />
      <Main>
        <Navbar />
        <Content>
          {children}
          <Outlet />
        </Content>
        <Footer />
      </Main>
    </Wrapper>
    <Settings />
  </React.Fragment>
)};

export default Dashboard;

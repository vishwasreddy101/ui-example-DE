import React , { useState , useEffect} from "react";
import { Helmet } from "react-helmet-async";
import Select from "react-select";
import { Button, Card, Col, Container, Form, Row , Accordion , Table} from "react-bootstrap";
import CSVFileReader from "./CSV-file-reader";
import 'react-bootstrap-range-slider/dist/react-bootstrap-range-slider.css';
import RangeSlider from 'react-bootstrap-range-slider';
import { getFilteredHCPData } from "../services/Rules-Engine-Service";





const hcpLifeStage = [
  { value: "Access/Support", label: "Access/Support" },
  { value: "General Brand Info", label: "General Brand Info"},
  { value: "Efficacy & Safety", label: "Efficacy & Safety" },
  { value: "Diagnosis", label: "Diagnosis" },
  { value: "Disease Information", label: "Disease Information" }
];
const hcpSpeciality = [
    { value: "Anesthesiology", label: "Anesthesiology" },
    { value: "Cardiology", label: "Cardiology"},
    { value: "Ophthalmology", label: "Ophthalmology" },
    { value: "Pediatrics", label: "Pediatrics" },
    { value: "Psychiatry", label: "Psychiatry" }
]



const FormRow = () => 
{

    const [CSVData,setCSVData] = useState([]);
    const [ hcpScoreValue, setHCPScoreValue ] = useState(0); 
    const [ hcpLifeStageValue, setHCPLifeStageValue ] = useState(null); 
    const [ hcpSpecialityValue, setHCPSpecialityValue] = useState(null); 
    const [ gender, setGender ] = useState(null); 
    const [result, setResult] = useState([]);



    const [filterFormObject,setFilterFormObject] = useState({"CSVData": CSVData,"hcpScoreValue":hcpScoreValue,"hcpLifeStageValue":hcpLifeStageValue,
                               "hcpSpecialityValue":hcpSpecialityValue,"gender":gender});
    
    useEffect(() => {
        setFilterFormObject({"CSVData": CSVData,"hcpScoreValue":hcpScoreValue,"hcpLifeStageValue":hcpLifeStageValue,
        "hcpSpecialityValue":hcpSpecialityValue,"gender":gender});
    }, [CSVData,hcpScoreValue,hcpLifeStageValue,hcpLifeStageValue,hcpSpecialityValue,gender]);
    
    const onSubmit = async () => {
        // event.preventDefault(); 
        try {
         getFilteredHCPData(filterFormObject).then((res) => {
            setResult(res.data);


        })} catch (e) {
          alert(`Registration failed! ${e.message}`);
        }
      }
    return(
      <>
  <Card>
    <Card.Header>
      {/* <Card.Title tag="h5">Filter Set</Card.Title> */}
      {/* <h6 className="card-subtitle text-muted">Bootstrap column layout.</h6> */}
    </Card.Header>
    <Card.Body>
      <Form>
      <Form.Group className="mb-3">

        <Row>
        <CSVFileReader setCSVData={setCSVData} />
        </Row>
        </Form.Group>
        <Form.Group className="mb-3">
        <Row>
        <h5>HCP Score </h5>
        <RangeSlider
         value={hcpScoreValue}
         onChange={changeEvent => setHCPScoreValue(changeEvent.target.value)}
         />
         <span>0 <span style={{marginLeft:"23rem"}}>100</span></span>
         </Row> 
         </Form.Group>  
        <Form.Group className="mb-3">
        {/* <Form.Label>Customer Segment</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={hcpLifeStage}
              className="text-muted"
              onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Select HCP lifestage as per journey..."
            />
        </Form.Group>
        <Form.Group className="mb-3">
        {/* <Form.Label>Select Campaign</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={hcpSpeciality}
              onChange={changeEvent => setHCPSpecialityValue(changeEvent.value)}
              className="text-muted"
              placeholder="Select HCP Speciality..."
            />
        </Form.Group>
        <Form.Group className="mb-3">
        <Form.Label>Gender</Form.Label>
        <div className="custom-control custom-checkbox">
          <input type="checkbox" className="custom-control-input" id="defaultUnchecked" onClick={changeEvent => setGender('male')}/>
          <label className="custom-control-label mx-1" htmlFor="defaultUnchecked">Male</label>
        </div>
      <div className="custom-control custom-checkbox">
        <input type="checkbox" className="custom-control-input" id="defaultUnchecked" onClick={changeEvent => setGender('female')}/>
        <label className="custom-control-label mx-1" htmlFor="defaultUnchecked">Female</label>
      </div>
        </Form.Group>
        <Button  onClick={onSubmit}variant="primary">Filter</Button>
      </Form>
    </Card.Body>
  </Card>
  <Row className="justify-content-center mt-3">
     <BorderedTable result={result}/>
    </Row>

    <Row className="justify-content-center mt-3">
     <h3>Next Best Action :</h3><span>{result[0] ? result[0]['NBA'] : ""}</span>
    </Row>


    </>
)};


const BorderedTable = ({result}) => 
   
  {   
  return(
    <>
    <Card>
    <Card.Header>
      <Card.Title tag="h5">Data Snapshot</Card.Title>
      {/* <h6 className="card-subtitle text-muted">
        Add <code>bordered</code> for borders on all sides of the table and
        cells.
      </h6> */}
    </Card.Header>
    <Table bordered>
      <thead>
        <tr>
          <th style={{ width: "40%" }}>HCP_Score</th>
          <th style={{ width: "25%" }}>Lifestage</th>
          <th className="d-none d-md-table-cell" style={{ width: "25%" }}>
            Specialty
          </th>
          <th>Gender</th>
        </tr>
      </thead>
      <tbody>
        {result ? result.map((rowData, index) => {
       return (  
       <tr key={index}>
          <td>{rowData.hcpScore}</td>
          <td>{rowData.lifeStage}</td>
          <td>{rowData.specialty}</td>
          <td>{rowData.gender}</td>
        </tr>
       );
        })  : <tr></tr>}
      </tbody>
    </Table>
  </Card>
  </>
  );
      };
const RulesEngine = () => {
  
  return (<React.Fragment>
  <Helmet title="Campaign Layout" />
  <Container fluid className="p-0">
    <h1 className="h3 mb-3">Rules Engine</h1>
    <h6 className="card-subtitle text-muted mb-3">
      Upload rules file or or use the default rules file
     </h6>
    <Row className="justify-content-center">
      <Col lg="6">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0" className="bg-white">
          <Accordion.Header>HCP Input Parameters</Accordion.Header>
          <Accordion.Body>
          <FormRow />
          </Accordion.Body>
        </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    
           </Container>
</React.Fragment>)
};

export default RulesEngine
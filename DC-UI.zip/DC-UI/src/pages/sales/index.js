import  { useState , useEffect} from 'react'
import RangeSlider from 'react-bootstrap-range-slider';
import { Card,Col,Row,Button } from "react-bootstrap";
import Select from "react-select";
import AreaChart from "./Area"
import { filterSalesData} from '../../services/Sales-Service'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";  



const businessItem = [
  { value: "Abi-order-total-discount", label: "Abi-order-total-discount" }
]


function Sales() {

  
  const [ rangeValue, setRangeValue ] = useState(0); 
  const [businessItemCurrentValue,setBusinessItemCurrentValue] = useState("");
  const [predictiveValue,setPredictiveValue] = useState("");
  const [cumulative_effect,setCumulative_effect] = useState("");
  const [point_effects,setPoint_effects] = useState("");
  const [startDate, setStartDate] = useState(new Date());



 
  useEffect(() => {
 
    },[]);
   
    const filterSales = () => {

      const filterData = {"campaign_start_date":startDate.toISOString().slice(0, 10),"lookback":Number(rangeValue)};
      console.log(filterData);
      filterSalesData(filterData).then(res =>{
        if(res){
          console.log(res.data['prd']);
        setPredictiveValue(res.data['prd']);
        setCumulative_effect(res.data['cumulative_effect']);
        setPoint_effects(res.data['point_effects']);
        }

      })
    }

  return (
    <>
    
     <Row> 
     <Col lg="2"/>  

     <Col lg="7">  
     <Card>
    <Card.Body className="mt-3"> 
    <div tag="h3">Select Campaign Start Date </div>
    <div className="mt-3">
    <DatePicker 
    selected={startDate} 
    placeholderText="Select Start Date"
    dateFormat="yyyy/MM/dd"
    onChange={(date) => setStartDate(date)} />
        </div>
    <div className="mt-3">
    <Select
              classNamePrefix="react-select"
              options={businessItem}
              className="text-muted"
              onChange={changeEvent => setBusinessItemCurrentValue(changeEvent.value)}
              placeholder="Select Business Item ..."
        />
        </div>
    <div className="mt-3" tag="h3">Look Back Windows in days </div>
<div className="mt-3">
    <RangeSlider
      value={rangeValue}
      min={0}
      max={1000}
      step={1}
      tooltip={"on"}
      onChange={changeEvent => setRangeValue(changeEvent.target.value)}
    />
    </div>
    <div className="mt-3" style={{float:"right"}}>
    <Button onClick={filterSales} variant="primary">Submit</Button>
    </div>
    </Card.Body>
    </Card>
    </Col>
    </Row>
    <Row>
    {predictiveValue ? <AreaChart customInputs={predictiveValue} graphType={"preds"} campaign_start_date={startDate.toISOString().slice(0, 10)}/> : <div></div>}
    </Row>
    <Row>
    {cumulative_effect ? <AreaChart customInputs={cumulative_effect} graphType={"cumulative_effect"} campaign_start_date={startDate.toISOString().slice(0, 10)}/>: <div></div>}
    </Row>
    <Row>
    {point_effects ? <AreaChart customInputs={point_effects} graphType={"point_effects"} campaign_start_date={startDate.toISOString().slice(0, 10)}/> : <div></div>}
    </Row>
   
   
    </>
  );
}

export default Sales
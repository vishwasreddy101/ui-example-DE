import Chart from "react-apexcharts";
import { Card } from "react-bootstrap"; // test

import usePalette from "../../hooks/usePalette";

const AreaChart = ({customInputs, graphType, campaign_start_date}) => {

  
  let campaign_start_date_x= campaign_start_date;
  let date_x = "";
  let original_y = "";
  let preds = "";
  let preds_lower = "";
  let preds_upper = "";
  
  if(graphType === "preds") {
   date_x = customInputs['date'];
   original_y = customInputs['original_y'];
   preds = customInputs['preds']
   preds_lower = customInputs['preds_lower'];
   preds_upper = customInputs['preds_upper'];

  } else  if( graphType === "cumulative_effect"){
   date_x = customInputs['date'];
   original_y = customInputs['post_cum_effects'];
   preds = [];
   preds_lower = customInputs['post_cum_effects_lower'];
   preds_upper = customInputs['post_cum_effects_upper'];

  } else if(graphType === "point_effects"){

   date_x = customInputs['date'];
   original_y = customInputs['point_effects'];
   preds = [];
   preds_lower = customInputs['point_effects_lower'];
   preds_upper = customInputs['point_effects_upper'];
  }
  

  const palette = usePalette();

  const data = [
    {
      name: "original_y",
      data: original_y
    },
    {
      name: "preds",
      data: preds
    },
    {
      name: "preds_lower",
      data: preds_lower
    },
    {
      name: "preds_upper",
      data: preds_upper
    }
  ];

  const options = {
    dataLabels: {
      enabled: false,
    },
    // stroke: {
    //   curve: "smooth",
    // },
    stroke: {
      curve: 'straight',
      dashArray: [0,0,5,5]
    },
    annotations: {
      xaxis: [{
        x: campaign_start_date_x,
        borderColor: '#999',
        yAxisIndex: 0,
        label: {
          show: true,
          text: 'Campaingn Start',
          style: {
            color: "#fff",
            background: '#775DD0'
          }
        }
      }]
    },
    yaxis: {
      title: {
        text: "Sales",
      }
    },
    xaxis: {
      title: {
        text: "Seasonal Business performance for " + graphType,
      },
      type: "date",
      categories: date_x,
    },
    tooltip: {
      x: {
        format: "dd MMM yyyy",
      },
    },
    colors: [
      palette.primary,
      palette.success,
      palette.warning,
      palette.warning,
      palette.info,
    ],
  };

  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">Business Performance using {graphType}</Card.Title>
        <h6 className="card-subtitle text-muted">
          Area charts are used to represent quantitative variations.
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart w-100">
          <Chart options={options} series={data} type="area" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default AreaChart;

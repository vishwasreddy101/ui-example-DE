
import React , { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import {
    Button,
    Card,
    Col,
    Container,
    Row,
    Modal,
    Form,
    Spinner,
    Accordion} from "react-bootstrap";
import nbaSteps from "../../assets/img/illustrations/nba-steps.png";
import Select from "react-select";
import MultiRangeSlider from "multi-range-slider-react";
import * as Icon from "react-feather";
import CSVFileReader from "../CSV-file-reader";
import { getNBADataForDropDown, getNBADataForSelectedCustomerID, getNBADataList , saveNBAConfigRulesForm , getNBAConfigRulesFormData} from "../../services/NBA-Service";
import { CSVLink } from "react-csv";
import StepProgress from "./StepProgress";


const hcpSpeciality = [
    { value: "Anesthesiology", label: "Anesthesiology" },
    { value: "Dermatology", label: "Dermatology"},
    { value: "Family medicine", label: "Family medicine" },
    { value: "Gynecology", label: "Gynecology" },
    { value: "Immunology", label: "Immunology" },
    { value: "Internal medicine", label: "Internal medicine" },
    { value: "Medical genetics", label: "Medical genetics" },
    { value: "Neurology", label: "Neurology" },
    { value: "Nuclear medicine", label: "Nuclear medicine" },
    { value: "Obstetrics", label: "Obstetrics" },
    { value: "Ophthalmology", label: "Ophthalmology" },
    { value: "Pathology", label: "Pathology" },
    { value: "Pediatrics", label: "Pediatrics" },
    { value: "Physical medicine", label: "Physical medicine" },
    { value: "Preventive medicine", label: "Preventive medicine" },
    { value: "Psychiatry", label: "Psychiatry" },
    { value: "Radiation oncology", label: "Radiation oncology" },
    { value: "Surgery", label: "Surgery" },
    { value: "Urology", label: "Urology" }
]

const hcpChannels = [

    { value: "All", label: "All" },
    { value: "Email", label: "Email"},
    { value: "SMS", label: "SMS" },
    { value: "WhatsApp", label: "WhatsApp" },
    { value: "Direct Mail", label: "Direct Mail" },
    { value: "Call", label: "Call" }

]

const hcpProductPromotions =[
    { value: "Tepezza", label: "Tepezza" }
]

const hcpContentAffinity  =[
  { value: "User-Item Recommender", label: "User-Item Recommender" },
  { value: "Collaborative filtring", label: "Collaborative filtring" }

]

const hcpChannelPreference  =[
  { value: "Channel Affinity model", label: "Channel Affinity model" }
]

const hcpOfferPropensity  =[
  { value: "Offer Propensity Model", label: "Offer Propensity Model" }
]

const hcpTimePropensity  =[
  { value: "Time Propensity Model", label: "Time Propensity Model" }
]

const availableContents = [

    { value: "TED CRM Month 2 Email", label: "TED CRM Month 2 Email" },
    { value: "TED CRM Month 3 Email", label: "TED CRM Month 3 Email"},
    { value: "TED CRM Month 2 Email with Welcome", label: "TED CRM Month 2 Email with Welcome"},
    { value: "TED CRM Month 1 Email with Welcome V2", label: "TED CRM Month 1 Email with Welcome V2" },
    { value: "TED CRM Month 4 Kickstarter Email", label: "TED CRM Month 4 Kickstarter Email" },
    { value: "TED CRM Month 4 Supporter Email", label: "TED CRM Month 4 Supporter Email" },
    { value: "TED CRM Month 5 Kickstarter Email", label: "TED CRM Month 5 Kickstarter Email" },
    { value: "TED CRM Month 5 Supporter Email", label: "TED CRM Month 5 Supporter Email" },
    { value: "2020 TEPEZZA HCP - Now Approved Email - Initial", label: "2020 TEPEZZA HCP - Now Approved Email - Initial" },
    { value: "2020 TEPEZZA HCP - Broadcast Email - Initial", label: "2020 TEPEZZA HCP - Broadcast Email - Initial" },
    { value: "2020 TEPEZZA HCP - Webcast Register Now Email - Initial", label: "2020 TEPEZZA HCP - Webcast Register Now Email - Initial" },
    { value: "2020 TEPEZZA HCP - Now Approved EM2 One-time Blast", label: "2020 TEPEZZA HCP - Now Approved EM2 One-time Blast" },
    { value: "HCP CRM Month 1 EM1 - Kickstarters", label: "HCP CRM Month 1 EM1 - Kickstarters" },
    { value: "HCP CRM Month 1 EM1 - Kickstarters NA", label: "HCP CRM Month 1 EM1 - Kickstarters NA" },
    { value: "HCP CRM Month 1 EM1 - Supporters & Referrers", label: "HCP CRM Month 1 EM1 - Supporters & Referrers" },
    { value: "HCP CRM Month 1 EM1 - Supporters & Referrers NA", label: "HCP CRM Month 1 EM1 - Supporters & Referrers NA" },
    { value: "HCP CRM Month 2 EM2 - Supporters & Referrers", label: "HCP CRM Month 2 EM2 - Supporters & Referrers" },
    { value: "HCP CRM Month 2 EM2 - Kickstarters", label: "HCP CRM Month 2 EM2 - Kickstarters" },
    { value: "HCP CRM Month 3 EM3 - Supporters & Referrers", label: "HCP CRM Month 3 EM3 - Supporters & Referrers" },
    { value: "HCP CRM Month 4 EM4 - Kickstarters", label: "HCP CRM Month 4 EM4 - Kickstarters" },
    { value: "HCP CRM Month 4 EM4 - Supporters & Referrers", label: "HCP CRM Month 4 EM4 - Supporters & Referrers" },
    { value: "HCP CRM Month 5 EM5 - Supporters & Referrers", label: "HCP CRM Month 5 EM5 - Supporters & Referrers" },
    { value: "HCP CRM Month 6 EM6 - Kickstarters", label: "HCP CRM Month 6 EM6 - Kickstarters" },
    { value: "HCP CRM Month 6 EM6 - Supporters & Referrers", label: "HCP CRM Month 6 EM6 - Supporters & Referrers" },
    { value: "HCP Virtual Booth AAO Pre-Conference email", label: "HCP Virtual Booth AAO Pre-Conference email" }

]

const ConfigurationSection = () => {

    const [configureRulesModal,setConfigureRulesModal] = useState(false);
    const [addDataModal,setAddDataModal] = useState(false);
    const [weightConfigurationModal,setWeightConfigurationModal] = useState(false);
    const [modelConfigurationAddModal,setModelConfigurationAddModal] = useState(false);
    
    // ------->
    const [hcpSpecialityCurrentValue,setHCPSpecialityCurrentValue] = useState("");
    const [availableChannels,setAvailableChannels] = useState("");
    const [gender,setGender] = useState({label:"",value:""});

    


    const [minValue, set_minValue] = useState(25);
    const [maxValue, set_maxValue] = useState(75);

    const [CSVData,setCSVData] = useState([]);


    useEffect(() => {
      getNBAConfigRulesFormData().then((res) => {
        if (res.data) {
         setHCPSpecialityCurrentValue(res.data["hcpSpeciality"]);
         setAvailableChannels(res.data["availableChannels"]);
         
      }
    });

    },[configureRulesModal]);

    const handleInput = (e) => {
        set_minValue(e.minValue);
        set_maxValue(e.maxValue);
      };
      const handleSubmit = (e) => {
        e.preventDefault();

        const formData = {"hcpSpeciality": hcpSpecialityCurrentValue,
                           "availableChannels": availableChannels}

        saveNBAConfigRulesForm(formData).then((res) => {
                            if (res.data) {
                             
                             
                          }
                        });
      
      }

    return(<>
      <Card>
    <Card.Body className="text-center"></Card.Body>
      <Row >
          <Col lg="6" >
      <div className="justify-content-center m-3" >
          <Button
            variant={`outline-primary`}
            style={{padding:"30px 70px",marginLeft:"35%"}}
            onClick={()=> setConfigureRulesModal(true)    
        }
          >
            Configure Rules
          </Button>
      </div>
      <div className="justify-content-center m-3" >
          <Button
            variant={`outline-primary`}
            style={{padding:"30px 65px",marginLeft:"35%"}}
            onClick={()=> setWeightConfigurationModal(true)    
            }
          >
            Configure Weight
          </Button>
      </div>
      </Col>
      <Col lg="6" >
      <div className=" justify-content-center m-3">
          <Button
            variant={`outline-primary`}
            style={{padding:"29px 85px"}}
            onClick={()=> setAddDataModal(true)    
            }
          >
            Add Data
          </Button>
      </div>
      <div className=" justify-content-center m-3">
          <Button
            variant={`outline-primary`}
            style={{padding:"29px 78px"}}
            onClick={()=> setModelConfigurationAddModal(true)    
            }
           >
            Add Models
          </Button>
      </div>
      </Col>
      </Row>

      {configureRulesModal ? 
      
       <Form>
          <Modal show={configureRulesModal} onHide={configureRulesModal}>
         <Modal.Header>
         <Modal.Title>Rules Configuration</Modal.Title>
       </Modal.Header>
       <Modal.Body>
           <Row className="mt-3">
        <Col lg="6" style={{zIndex:"9999"}}> 
         <Select
              classNamePrefix="react-select"
              options={hcpSpeciality}
              value={hcpSpecialityCurrentValue}
              className="text-muted"
              onChange={changeEvent => setHCPSpecialityCurrentValue(changeEvent)}
              placeholder="Select HCP Speciality ..."
        />
        </Col>

        <Col lg="6"> 
         <Select
              classNamePrefix="react-select"
              options={hcpChannels}
              value={availableChannels}
              className="text-muted"
              onChange={changeEvent => setAvailableChannels(changeEvent)}
              placeholder="Available Channels ..."
              isMulti
        />
        
        </Col>

                </Row>
             <Row className="mt-3">
             <Col lg="6"> 
   
             <Form.Label>Gender</Form.Label>
             <Form.Group className="mb-3">
                <div className="custom-control custom-checkbox">
                   <input type="checkbox" checked={gender["value"]} value={gender["label"]} onChange={() => setGender({label:"male",value:true})} id="defaultUnchecked" />
                   <label className="custom-control-label mx-1" htmlFor="defaultUnchecked">Male</label>
               </div>
                <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id="defaultUnchecked"/>
                    <label className="custom-control-label mx-1" htmlFor="defaultUnchecked">Female</label>
               </div>
               <div className="custom-control custom-checkbox">
                    <input type="checkbox" className="custom-control-input" id="defaultUnchecked"/>
                    <label className="custom-control-label mx-1" htmlFor="defaultUnchecked">Other</label>
               </div>
             </Form.Group>
            <div>
            <h5 className="text-muted">Engagement Score</h5>
            <MultiRangeSlider
              className="text-muted"
              min={0}
              max={100}
              step={1}
              ruler={false}
              label={true}
              preventWheel={true}
              minValue={minValue}
              maxValue={maxValue}
              onInput={(e) => {
             handleInput(e);
            }}
            />
            </div>
             </Col>
             <Col lg="6">
             <Form.Group controlId="doj">
                            <Form.Label>TimeFrame for Promotions</Form.Label>
                            <Form.Control 
                                 type="date" 
                                 name="doj" 
                                 className="text-muted"
                                //  defaultValue={this.props.selectedValue} 
                                 placeholder="TimeFrame" 
                                //  onChange={(e) => this.props.onChange(e)} 
                                 />
                        </Form.Group>
              <div lg="6" className ="mt-3">
             <Select
              className="text-muted"
              classNamePrefix="react-select"
              options={hcpProductPromotions}
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Product for Promotion ..."
              isMulti
              />
              </div>
              <div className ="mt-3">
              <Select
              classNamePrefix="react-select"
              options={availableContents}
              className="text-muted"
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Available Contents ..."
              isMulti
              />
             </div>
             </Col>
            </Row>
            <Row>
            
            </Row>   
            </Modal.Body>
           <Modal.Footer>
         <Button  onClick={handleSubmit}>Save</Button>
         <div style={{marginRight:"13%",marginLeft:"16%"}}> <Icon.Download /> Download Rules Configuration in CSV </div>
         <Button onClick={()=>setConfigureRulesModal(false)}>Close</Button>
       </Modal.Footer>
        </Modal>
      </Form>
         

       : <div></div>}


     {modelConfigurationAddModal ? 
       
       <Form>
         <Modal show={modelConfigurationAddModal} onHide={modelConfigurationAddModal}>
       <Modal.Header>
         <Modal.Title>Model Configuration</Modal.Title>
       </Modal.Header>
       <Modal.Body>
           <Row className="mt-3">
        <Col lg="6"> 
         <Select
              classNamePrefix="react-select"
              options={hcpContentAffinity}
              className="text-muted"
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Content Affinity ..."
        />
        </Col>

        <Col lg="6"> 
         <Select
              classNamePrefix="react-select"
              options={hcpOfferPropensity}
              className="text-muted"
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Offer Propensity ..."
              isMulti
        />
        
        </Col>
                </Row>
                <Row className="mt-3">
        <Col lg="6"> 
         <Select
              classNamePrefix="react-select"
              options={hcpChannelPreference}
              className="text-muted"
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Channel Preference ..."
        />
        </Col>

        <Col lg="6"> 
         <Select
              classNamePrefix="react-select"
              options={hcpTimePropensity}
              className="text-muted"
            //   onChange={changeEvent => setHCPLifeStageValue(changeEvent.value)}
              placeholder="Time Propensity ..."
              isMulti
        />
        
        </Col>
                </Row> 
                </Modal.Body>
         <Modal.Footer>
         <Button type="submit" onClick={()=>setModelConfigurationAddModal(false)}>Save</Button>
         <div style={{marginRight:"12%",marginLeft:"16%"}}> <Icon.Download /> Download Model Configuration in CSV </div>
         <Button onClick={()=>setModelConfigurationAddModal(false)}>Close</Button>
         </Modal.Footer>
        </Modal>                
           </Form>
         

        : <div></div>}




     {addDataModal ? 
       <Modal show={addDataModal} onHide={addDataModal}>
       <Modal.Header>
         <Modal.Title>Add Data</Modal.Title>
       </Modal.Header>
       <Modal.Body>
       <Form>
           <Row className="mt-3">
             <Col lg="6"> 
             <h5>Upload Transaction Data</h5>
             <CSVFileReader setCSVData={setCSVData} />
             <Form.Control className="mt-2" type="text" name="input" placeholder="Provide URL of the DataSource " />
             <Button className="mt-2" variant="primary">
             <Icon.Database /> Connect to DataBase
             </Button>

            </Col>

            <Col lg="6"> 
            <h5>Upload Customer Data</h5>
            <CSVFileReader setCSVData={setCSVData} />
            <Form.Control className="mt-2" type="text" name="input" placeholder="Provide URL of the DataSource " />
            <Button className="mt-2" variant="primary" >
            <Icon.Database /> Connect to DataBase
             </Button>
            </Col>

          </Row>
            

        </Form>
         

       </Modal.Body>
       <Modal.Footer>
         <Button style={{marginRight:"55%"}} onClick={()=>setAddDataModal(false)}>Save Data Location</Button>
         {/* <div style={{marginRight:"13%",marginLeft:"16%"}}> <Icon.Download /> Download Rules Configuration in CSV </div> */}
         <Button onClick={()=>setAddDataModal(false)}>Reset form</Button>
       </Modal.Footer>
     </Modal> : <div></div>}

     {weightConfigurationModal ? 
       <Modal show={weightConfigurationModal} onHide={weightConfigurationModal}>
       <Modal.Header>
         <Modal.Title>Weight Configuration</Modal.Title>
       </Modal.Header>
       <Modal.Body>
       <Form>
           <Row className="mt-3">
             <Col lg="6"> 
             <h5>Engagement Score</h5>
            
                  <div><span style={{marginRight:"10px"}} >Recieve Mail </span><input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"25px"}}>Open Mail </span><input type="number" defaultValue="1" min="1" max="999"  step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"29px"}}>Click Mail </span> <input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
            </Col>
            <Col lg="6"> 
             <h5>Hcp Tenure Weight</h5>
            
                  <div><span style={{marginRight:"10px"}}>greater than 10 years </span><input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"85px"}}>6-8 years </span><input type="number" defaultValue="1" min="1" max="999"  step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"86px"}}>2-5 years </span> <input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"38px"}}>less than 2 years </span> <input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>

            </Col>

          </Row>

          <Row className="mt-3">
             <Col lg="6"> 
             <h5>Offer Weights</h5>
            
                  <div><span style={{marginRight:"40px"}} >Buy 1 get 1 </span><input type="number" defaultValue="1" min="1" max="999"  step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"6px"}}>Discount offers </span><input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"10px"}}>Reward points </span> <input type="number" defaultValue="1" min="1" max="999" step=".01"  style={{fontSize: "10px"}}/></div>
            </Col>
            <Col lg="6"> 
             <h5>Product on Promotion Weights</h5>
            
                  <div><span style={{marginRight:"10px"}}>product 1 </span><input type="number" defaultValue="1" min="1" max="999"  step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"7px"}}>product 2 </span><input type="number" defaultValue="1" min="1" max="999" step=".01" style={{fontSize: "10px"}}/></div>
                  <div><span style={{marginRight:"7px"}}>product 3 </span> <input type="number" defaultValue="1" min="1" max="999" step=".01"  style={{fontSize: "10px"}}/></div>

            </Col>

          </Row>
            

        </Form>
         

       </Modal.Body>
       <Modal.Footer>
         <Button onClick={()=>setWeightConfigurationModal(false)}>Save</Button>
         <div style={{marginRight:"10%",marginLeft:"16%"}}> <Icon.Download /> Download Weights Configuration in CSV </div>
         <Button onClick={()=>setWeightConfigurationModal(false)}>Close</Button>
       </Modal.Footer>
     </Modal> : <div></div>}

    

    
      </Card>
    
    </>);

}

 const NextBestActionRecommendationForm = () => {

    const [customerDataId,setCustomerDataId] = useState([]);

    const [selectedOption, setSelectedOption] = useState(null);
    const [responseOfSelectedCustomerData, setResponseOfSelectedCustomerData] = useState({});
    const [responseDataList, setResponseDataList] = useState([]);

    const [timerCondition, setTimerCondition] = useState(false);

    const headers = [ { label: "NPI_NUMBER", key: "NPI_NUMBER" },
    { label: "Right Content", key: "Right Content" },
    { label: "Right Time", key: "Right Time" },
    { label: "Right Product", key: "Right Product" }]
    const csvReport = {
      data: responseDataList,
      headers: headers,
      filename: 'nba_recommendation_list.csv'
    };

    useEffect(() => {
      if(selectedOption){
        setTimerCondition(true);

      getNBADataForSelectedCustomerID(selectedOption).then((res) => {
          if (res.data) {
           
            setTimeout(() => {
              setResponseOfSelectedCustomerData(res.data);
              setTimerCondition(false);

            }, 3000);
        }
      });
    }

    getNBADataForDropDown().then(res => {
      if(res){
         setCustomerDataId(res.data);
      }
      
    });

      getNBADataList().then((res) => {
        if (res.data) {
         
          setResponseDataList(res.data);
        
       }
    });
  
    }, [selectedOption]);

    return(
        <Card>
      <Card.Header>
      <Card.Title tag="h5" className="mb-0">
      Next Best Actions Recommendations </Card.Title>
      </Card.Header>
      <Card.Body>
      <Row className="mt-3">
        <Row className="mt-2">
        <Col lg="4">

           <Form.Group >
            <Select
              className="text-muted"
              classNamePrefix="react-select"
              options={customerDataId}
              placeholder="Select Customer ..."
              onChange={e => setSelectedOption(e.value)}
              isSearchable
            />
          </Form.Group>
          </Col>  

          </Row>
        <Col lg="6">

       <Row className="mt-5 mb-5 " style={{boxShadow: "0px 0px 0px 1px #000"}}>
       <h4><span className="m-1"><Icon.Radio/></span> Right Channel : <div className="m-2"><span  style={{color:"green"}}>{responseOfSelectedCustomerData['Right Channel']}</span></div></h4>
       </Row>
       <Row className="mt-5 mb-5 " style={{boxShadow: "0px 0px 0px 1px #000"}}>
         <h4><span className="m-1"><Icon.Gift/></span>Right Offer : <div className="m-2" ><span style={{color:"green"}}>{responseOfSelectedCustomerData['Right Content']} </span></div> </h4>
       </Row>

        </Col >
        {timerCondition ? <span style={{zIndex:"9999",position:"absolute",top:"50%",left:"45%"}}><Spinner animation="border" variant="primary" className="me-2" /></span> : <span style={{zIndex:"9999",position:"absolute"}}></span> } 


        <Col lg="6">

        <Row className="mt-5 mb-5 " style={{boxShadow: "0px 0px 0px 1px #000"}}>
        <h4><span className="m-1" ><Icon.Clock/></span>Right Time to Reach : <div className="m-2"><span  style={{color:"green"}}>{responseOfSelectedCustomerData['Right Time']}</span></div></h4>
       </Row>
       <Row className="mt-5 mb-5" style={{boxShadow: "0px 0px 0px 1px #000"}}>
         <h4><span className="m-1"><Icon.Box/></span>Right Product : <div className="m-2"><span  style={{color:"green"}}>{responseOfSelectedCustomerData['Right Product']}</span></div></h4>
       </Row>
        </Col>

        <Row className="">
        <CSVLink {...csvReport}><div> <Icon.Download/> Download Recommendations for all customers in CSV </div></CSVLink>  
        </Row>
       
      </Row>
     
      </Card.Body>
      </Card>
    );
}

const NextBestAction = () => {


return(<React.Fragment>
    <Helmet title="Campaign Layout" />
    <Container fluid className="p-0">
      <h1 className="h3 mb-3">Next Best Action</h1>
      <h6 className="card-subtitle text-muted mb-3">
      Reach your customers at 1:1 personalisation using right channel,right content,right offer at the right time
      .Improve your ROI by 3x and generate a fullfilling and rewarding customer journey for each customer </h6>
      <Row className="justify-content-center">
        <Col lg="12">
        <Accordion >
          <Accordion.Item eventKey="0" className="bg-white">
            <Accordion.Header>Filters</Accordion.Header>
            <Accordion.Body>
            <ConfigurationSection />
            </Accordion.Body>
          </Accordion.Item>
          </Accordion>
        </Col>
      </Row>
      <Row  className="m-3">
      <Col lg="12">
      <StepProgress/>
      </Col>
      </Row>
      <Row>
      <img
                      className="img-fluid"
                      src={nbaSteps}
                      alt="4r"
                    />
      </Row>
      {/* <Row>
      <img
                      className="img-fluid"
                      src={fourRImage}
                      alt="4r"
                    />
      </Row> */}
      <Row className="mt-3">
      <Col lg="12">
     <NextBestActionRecommendationForm />
      </Col>
      </Row>
      </Container>
      </React.Fragment>
      );
};

export default NextBestAction;

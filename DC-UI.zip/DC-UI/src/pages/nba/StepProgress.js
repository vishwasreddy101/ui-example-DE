import React, { useEffect , useState} from "react";
import * as Icon from "react-feather";


import { Card, Dropdown  , Button} from "react-bootstrap";
// import the progress bar
import StepProgressBar from 'react-step-progress';
// import the stylesheet
import 'react-step-progress/dist/index.css';

import { MoreHorizontal } from "react-feather";


// let step4Content = <div className="mt-3"><h3>1438.6 MB</h3></div>;
// let testVar = null;
// let step3Content = <div></div>
// let step3Content = <div className="mt-3"><h3>1438.6 MB</h3></div>;


 
// setup step validators, will be called before proceeding to the next step
function step2Validator() {
  // return a boolean
        return true;
}
 
function step3Validator() {
  // return a boolean
        return true;

}
 
function onFormSubmit() {
  // handle the submit logic here
  // This function will be executed at the last step
  // when the submit button (next button in the previous steps) is pressed
}



const StepProgress = ({ dagId }) => {

  
  
    function Intialized() {


      document.querySelector('._hsN1w').click();

      setTimeout(() => {
        document.querySelector('._hsN1w').click();
      }, 250);
      
    };
  
  useEffect(() => {
                // step3Content = <div className="mt-3"><h3>{ taskID }</h3></div>;
            },[]); 

  return (
  
  <Card className="flex-fill w-100">
    <Card.Header>
      <div className="card-actions float-end">
        <Dropdown align="end">
          <Dropdown.Toggle as="a" bsPrefix="-">
            <MoreHorizontal />
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another Action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
      {/* <Card.Title tag="h5" className="mb-0">
        TD-Bank
      </Card.Title> */}
      </Card.Header>

      <Card.Body className="text-center">
      <div>
      <Button  className="p-3" variant="primary" onClick={Intialized}
>
             <Icon.Play /> Execute Model
      </Button>
      </div>
      <div>
        <span style={{
          position: "relative",
          top: "210px",
          right: "80px"
        }}><h5>Status :</h5></span>
            
    
    <StepProgressBar 
      startingStep={0}
      onSubmit={onFormSubmit}
      steps={[
        {
          label: 'Step 1',
          subtitle: 'Reading the data',
          name: 'step 1'
          //   content: step1Content
        },
        {
          label: 'Step 2',
          subtitle: 'Reading rules and weights',
          name: 'step 2',
          //   content: step2Content,
          validator: step2Validator
        },
        {
          label: 'Step 3',
          subtitle: 'Running Model',
          name: 'step 3',
          // content: step3Content,
          validator: step3Validator
        },
         {
          label: 'Step 4',
          subtitle: 'Generating Results',
          name: 'step 4'
          // content: step4Content
        }
      ]}
        />
      </div>
        </Card.Body>
  </Card>
  )
};

export default StepProgress;

import React, { useEffect, useState } from "react";
import Select from "react-select";
import { Card, Container,Col, Row , Table ,Form, Badge} from "react-bootstrap";
import { Helmet } from "react-helmet-async";
import { getCustomerJourneyTableData } from "../services/Dashboard-Service";


const options = [
  { value: "10003408", label: "10003408" },
  { value: "10003409", label: "10003409" },
  { value: "10003410", label: "10003410" },
  { value: "10003411", label: "10003411" },
  { value: "10003412", label: "10003412" },

];




const ProfileDetails = ({customerJourneyData}) => {

  let imgSrc = "../assets/img/avatars/"+customerJourneyData.customer_name.replace(/ /g, "")+ ".jpg";
  
  return (
  <Card>
    <Card.Header>
      <Card.Title tag="h5" className="mb-0">
        Profile Details
      </Card.Title>
    </Card.Header>
    <Row>
    <Col lg="4">
    <Card.Body>
      <img
        src={require("../assets/img/avatars/"+customerJourneyData.customer_name.replace(/ /g, "")+ ".jpg").default}
        alt={customerJourneyData.customer_name}
        className="img-fluid mb-2"
        width="128"
        height="128"
      /> 

      <Card.Title tag="h5" className="mb-0">
       {customerJourneyData && customerJourneyData.customer_name} 
      </Card.Title>
      <div className="text-muted mb-2">Lead Developer</div>
    </Card.Body>
    </Col>

    <Col lg="4">
      <Card.Body className="mt-3">
      <Card.Title tag="h5">Reasons</Card.Title>
      {customerJourneyData ? customerJourneyData.traits.map((rowData, index) => {
     return( 
     <>
     <Badge bg="primary" className="me-2 my-1">
      {rowData}
      </Badge>
      </>
     );
      })  : null}
      
    </Card.Body>
    </Col>

    </Row>


       
  </Card>
  )};




const BasicTable = ({customerJourneyData}) => { 

  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">Customer Journey</Card.Title>
      </Card.Header>
      <Table responsive className="table-borderless">
        <thead>
          <tr>
          <th>
              <div>Steps</div>
              </th>

            {/* {customerJourneyData.steps[0] ? */}
            <th>
            <div className="text" style={{ backgroundColor: "#c3e3c1" , whiteSpace: "pre-wrap"}}>Awareness<span style={{ borderLeftColor:"#c3e3c1" }} className="arrow"></span></div>
            </th>
            {/* :<></>} */}

            {/* {customerJourneyData.steps[1] ? */}
            <th>
            <div className="text" style={{ backgroundColor: "#d5e8d3" }}>Interest<span style={{ borderLeftColor:"#d5e8d3" }} className="arrow"></span></div>
            </th>
            {/* :<></>} */}

            {/* {customerJourneyData.steps[2] ? */}
            <th>
            <div className="text" style={{ backgroundColor: "#c3e3c1" }}>Purchase<span style={{ borderLeftColor:"#c3e3c1" }} className="arrow"></span></div>
            </th>
            {/* :<></>} */}

            {/* {customerJourneyData.steps[3] ? */}
            <th>
            <div className="text" style={{ backgroundColor: "#d5e8d3" }}>Experience<span style={{ borderLeftColor:"#d5e8d3" }} className="arrow"></span></div>
            </th>
            {/* :<></>} */}

            {/* {customerJourneyData.steps[4]  ? */}

            <th>
            <div className="text" style={{ backgroundColor: "#c3e3c1" }}>Loyalty<span style={{ borderLeftColor:"#c3e3c1" }} className="arrow"></span></div>
            </th>
            {/* :<></>} */}

          </tr>
        </thead>
        <tbody>  
        {customerJourneyData ? ['Description','Customer Attributes','Product Attributes','Transactional Attributes','Next Best Action'].map((rowData, index) => {
         return ( 
           <>
           <tr key={index}>
            <td>{rowData}</td>
            { customerJourneyData.steps[0]  ? <td style={{ backgroundColor: "#c3e3c1" }}>{customerJourneyData.steps[0][rowData]}</td> : <td>-</td>}
            { customerJourneyData.steps[1]  ? <td style={{ backgroundColor: "#d5e8d3" }}>{customerJourneyData.steps[1][rowData]}</td> : <td>-</td>}
            { customerJourneyData.steps[2]  ? <td style={{ backgroundColor: "#c3e3c1" }} >{customerJourneyData.steps[2][rowData]}</td> : <td>-</td>}
            { customerJourneyData.steps[3]  ? <td  style={{ backgroundColor: "#d5e8d3" }} >{customerJourneyData.steps[3][rowData]}</td> : <td>-</td>}
            { customerJourneyData.steps[4]  ? <td style={{ backgroundColor: "#c3e3c1" }}>{customerJourneyData.steps[4][rowData]}</td> : <td>-</td>}
            </tr> 
          </>
         );
        })  : <tr></tr>}
        <tr>
            <td></td>
            { customerJourneyData.steps[0].status.value !== ''  ? <td style={{ backgroundColor: "#c3e3c1" }}><div className="box arrow-top"><span className=" align-self-center ">{customerJourneyData.steps[0].status.value}</span><hr/>{customerJourneyData.steps[0].status.Reason}</div></td> : <td style={{ backgroundColor: "#c3e3c1" }}></td>}
            { customerJourneyData.steps[1].status.value !== '' ? <td style={{ backgroundColor: "#d5e8d3" }}><div className="box arrow-top"><span className=" align-self-center ">{customerJourneyData.steps[1].status.value}</span><hr/>{customerJourneyData.steps[1].status.Reason}</div></td> : <td style={{ backgroundColor: "#d5e8d3" }}></td>}
             { customerJourneyData.steps[2].status.value !== '' ? <td style={{ backgroundColor: "#c3e3c1" }} ><div className="box arrow-top"><span className=" align-self-center ">{customerJourneyData.steps[2].status.value}</span><hr/>{customerJourneyData.steps[2].status.Reason}</div></td> : <td style={{ backgroundColor: "#c3e3c1" }}></td>}
             { customerJourneyData.steps[3].status.value !== '' ? <td  style={{ backgroundColor: "#d5e8d3" }} ><div className="box arrow-top"><span className=" align-self-center ">{customerJourneyData.steps[3].status.value}</span><hr/>{customerJourneyData.steps[3].status.Reason}</div></td> : <td style={{ backgroundColor: "#d5e8d3" }}></td>}
             { customerJourneyData.steps[4].status.value !== '' ? <td style={{ backgroundColor: "#c3e3c1" }}><div className="box arrow-top"><span className=" align-self-center ">{customerJourneyData.steps[4].status.value}</span><hr/>{customerJourneyData.steps[4].status.Reason}</div></td>  : <td style={{ backgroundColor: "#c3e3c1" }}></td>}         
        </tr>
        </tbody>
      </Table>
    </Card>
  )};
  
  
function CustomerJourney() {

   const [customerJourneyData , setCustomerJourneyData] = useState(null);
   const [selectedOption, setSelectedOption] = useState(options[0].value);

   useEffect(() => {
     console.log(selectedOption);
    getCustomerJourneyTableData(selectedOption).then(res => {
      if(res){
        setCustomerJourneyData(res.data[0]);
      }
      
    });
    }, [selectedOption]);

  return (

    <React.Fragment>
    <Helmet title="Tables" />
    <Container fluid className="p-0">
      {/* <h1 className="h3 mb-3">Tables</h1> */}
     <Row>

     <Col lg="6">
     <Col lg="4">
     <Form.Group className="mb-3 w-100">
            <Form.Label>Customer Select</Form.Label>
            <Select
              className="react-select-container"
              classNamePrefix="react-select"
              options={options}
              placeholder={selectedOption}
              onChange={e => setSelectedOption(e.value)}
              isSearchable
            />
          </Form.Group>
       </Col>
     { customerJourneyData ?<ProfileDetails customerJourneyData={customerJourneyData}/>: <div></div> }
     </Col>
       </Row>
      <Row>
      <Col lg="12">
       { customerJourneyData ? <BasicTable customerJourneyData={customerJourneyData}/> : <div></div> }
        </Col>
      </Row>
    </Container>
  </React.Fragment>
  )
}

export default CustomerJourney;

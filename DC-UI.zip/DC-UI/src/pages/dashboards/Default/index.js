import React from "react";
import { Helmet } from "react-helmet-async";
import { Container } from "react-bootstrap";
import Header from "./Header";
import { Col, Card, Row } from "react-bootstrap";
import illustration from "../../../assets/img/illustrations/customer-support.png";
import { useTranslation } from "react-i18next";
import { ArrowRightCircle } from "react-feather";
import { Link } from 'react-router-dom'
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const Default = () => {
  const { t } = useTranslation();

  return (
    <React.Fragment>
      <Helmet title="Default Dashboard" />
      <Container fluid className="p-0">
        <Header />
        <Row>
          <Col md="6" xl className="d-flex">
            <Card className="illustration flex-fill">
              <Card.Body className="p-0 d-flex flex-fill">
                <Row className="g-0 w-100">
                  <Col xs="6">
                    <div className="illustration-text p-3 m-1">
                      <h4 className="illustration-text">
                        {t("Welcome back")}, {localStorage.getItem('userName')}!
                      </h4>
                      <p className="mb-0">Decision Engine</p>
                    </div>
                  </Col>
                  <Col xs={6} className="align-self-end text-end">
                    <img
                      src={illustration}
                      alt="Customer Support"
                      className="img-fluid illustration-img"
                    />
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
          <Row className="nowrap">

            <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
              <Card className="flex-fill w-100">
                <Card.Header>
                  <Card.Title tag="h5" className="mb-2">
                    Customer Acquisition Summary
                  </Card.Title>
                </Card.Header>
                <Card.Body className="d-flex">
                  <Row>
                    <Col lg="6">
                      <Card className="flex-fill" style={{ backgroundColor: "grey" , height: "65%"}}>
                        <div className="align-items-center  flex-column  d-flex justify-content-center">  
                        <Card.Body >
                          <Row>
                            <Col className="mt-0">
                              <h5 className="card-title mx-4 text-white">Current Month</h5>
                            </Col>
                          </Row>
                          <Row>
                            <span className="h4 d-inline-block mx-3 mt-0 mb-0 text-white">New Customers</span>
                          </Row>
                          <Row>
                            <span className="h2 d-inline-block mx-5 mt-0 mb-0  text-white ">34k</span>
                          </Row>
                          <Row>
                            <span className="h5 d-inline-block mt-0 mb-0 text-white">(+3% vs Previous Period)</span>
                          </Row>
                        </Card.Body>
                        </div>
                      </Card>
                    </Col>
                    <Col lg="6" >
                    <h5>Share of sales from new customers</h5>
                      <CircularProgressbar className="h-50" value={12} text={`${12}%`} styles={buildStyles({
                            textColor: '#f88',
                            pathColor: '#f88'
                       })}/>
                    </Col>
                  </Row>
                </Card.Body>
                <div className="mx-2">
                  <Link to='../customer-acquisition'>
                  Details
                  <ArrowRightCircle className="align-middle text-success" />
                  </Link>
                  </div>
              </Card>

            </Col>

            <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
               <Card className="flex-fill w-100">
                <Card.Header>
                  <Card.Title tag="h5" className="mb-2">
                    Customer Loyalty Summary
                  </Card.Title>
                </Card.Header>
                <Card.Body className="d-flex ">
                  <Row>
                    <Col lg="6">
                      <Card className="flex-fill" style={{ backgroundColor: "grey" , height: "65%"}}>
                        <Card.Body >
                          <Row>
                            <Col className="mt-0">
                              <h5 className="card-title  mx-4 text-white">Current Month</h5>
                            </Col>
                          </Row>
                          <Row>
                            <span className="h4 d-inline-block mx-3 mt-0 mb-0 text-white">Avg Transaction Value(members)</span>
                          </Row>
                          <Row>
                            <span className="h2 d-inline-block mt-0 mb-0 mx-5 text-white ">$245</span>
                          </Row>
                          <Row>
                            <span className="h5 d-inline-block mt-0 mb-0 text-white">(+4% vs Previous Period)</span>
                          </Row>
                        </Card.Body>
                      </Card>
                    </Col>
                    <Col lg="6" >
                    <h5>Share of Loyalty members in total customer base</h5>
                      <CircularProgressbar className="h-50" value={82} text={`${82}%`} styles={buildStyles({
                            textColor: '#9803fc',
                            pathColor: '#9803fc'
                       })}/>
                    </Col>
                  </Row>
                </Card.Body>
                <div className="mx-2">
                  <Link to='../customer-loyality'>Details
                  <ArrowRightCircle className="align-middle text-success" />
                  </Link>
                  </div>
              </Card>

            </Col>
              <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
              <Card className="flex-fill w-100">
                <Card.Header>
                  <Card.Title tag="h5" className="mb-2">
                    Customer Retention and Churn 
                  </Card.Title>
                </Card.Header>
                <Card.Body className="d-flex ">
                  <Row>
                    <Col lg="6">
                      <Card className="flex-fill" style={{ backgroundColor: "grey" , height: "65%"}}>
                        <Card.Body >
                          <Row>
                            <Col className="mt-0">
                              <h5 className="card-title  mx-4 text-white">Current Month</h5>
                            </Col>
                          </Row>
                          <Row>
                            <span className="h4 d-inline-block mx-2 mt-0 mb-0 text-white">Revenue loss from churned customers</span>
                          </Row>
                          <Row>
                            <span className="h2 d-inline-block mt-0 mb-0 mx-5 text-white ">34k</span>
                          </Row>
                          <Row>
                            <span className="h5 d-inline-block mt-0 mb-0 text-white">(+3% vs Previous Period)</span>
                          </Row>
                        </Card.Body>
                      </Card>
                    </Col>
                    <Col lg="6" >
                    <h5>Churned Customers in Current Month</h5>
                      <CircularProgressbar className="h-50" value={4.50} text={`${4.50}%`}
                      styles={buildStyles({
                        textColor: '#0373fc',
                        pathColor: '#0373fc'
                   })} />
                    </Col>
                  </Row>
                </Card.Body>
                <div className="mx-2">
                  <Link to='../customer-retention'>Details
                  <ArrowRightCircle className="align-middle text-success" />
                  </Link>
                  </div>
              </Card>

              </Col>
              
              <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
              <Card className="flex-fill w-100">
                <Card.Header>
                  <Card.Title tag="h5" className="mb-2">
                    Campaign Response & ROI 
                  </Card.Title>
                </Card.Header>
                <Card.Body className="d-flex ">
                  <Row>
                    <Col lg="6">
                      <Card className="flex-fill" style={{ backgroundColor: "grey" , height: "65%"}}>
                        <Card.Body >
                          <Row>
                            <Col className="mt-0">
                              <h5 className="card-title  mx-4 text-white">Current Month</h5>
                            </Col>
                          </Row>
                          <Row>
                            <span className="h4 d-inline-block mx-4 mt-0 mb-0 text-white">Incremental Revenue</span>
                          </Row>
                          <Row>
                            <span className="h2 d-inline-block mx-4 mt-0 mb-0  text-white ">$443,000</span>
                          </Row>
                          <Row>
                            <span className="h5 d-inline-block mt-0 mb-0 text-white">(+3% vs Previous Period)</span>
                          </Row>
                        </Card.Body>
                      </Card>
                    </Col>
                    <Col lg="6" >
                    <h5>Share of sales from new customers</h5>
                      <CircularProgressbar className="h-50" value={10.5} text={`${10.5}%`} styles={buildStyles({
                            textColor: '#03fc7f',
                            pathColor: '#03fc7f'
                       })}/>
                    </Col>
                  </Row>
                </Card.Body>
                <div className="mx-2">
                  <Link to='../campaign-details'>Details
                  <ArrowRightCircle className="align-middle text-success" />
                  </Link>
                  </div>
              </Card>

              </Col>

          </Row>
        </Row>
      </Container>
    </React.Fragment>
  )
};

export default Default;

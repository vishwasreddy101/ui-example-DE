import React , { useEffect} from "react";
import { Bar } from "react-chartjs-2";

import { Card, Dropdown } from "react-bootstrap";

import { MoreHorizontal } from "react-feather";

import usePalette from "../../../hooks/usePalette";

import { getCSVDataByGenderSegment }  from '../../../services/Dashboard-Service';


const BarChart = () => {
  const palette = usePalette();

  
  useEffect(() => {
    
    getCSVDataByGenderSegment().then(res => {
      const dataset = [];
      if (res === 'undefined') {
        res.data.columns.map(x =>
          dataset.push({ label: x, data: [] })
        )
        res.data.columns.map(x =>
          dataset.push({ label: x, data: [] })
        )
      }
    });
    }, []);

  const data = {
    labels: [
      "Segment 1",
      "Segment 2",
      "Segment 3"
    ],
    datasets: [
      {
        label: "Male",
        backgroundColor: palette.primary,
        borderColor: palette.primary,
        hoverBackgroundColor: palette.primary,
        hoverBorderColor: palette.primary,
        data: [3,2,1],
        barPercentage: 0.5,
        categoryPercentage: 0.5,
      },
      {
        label: "Female",
        backgroundColor: palette.warning,
        borderColor: palette.warning,
        hoverBackgroundColor: palette.warning,
        hoverBorderColor: palette.warning,
        data: [2,1,0],
        barPercentage: 0.5,
        categoryPercentage: 0.5,
      },
    ],
  };

  const options = {
    maintainAspectRatio: false,
    cornerRadius: 15,
    legend: {
      display: false,
    },
    type: "bar",

    // scales: {
    //   yAxes: [
    //     {
    //       gridLines: {
    //         display: false,
    //       },
    //       ticks: {
    //         stepSize: 20,
    //       },
    //       stacked: true,
    //     },
    //   ],
    //   xAxes: [
    //     {
    //       gridLines: {
    //         color: "transparent",
    //       },
    //       stacked: true,
    //     },
    //   ],
    // },
  };

  return (
    <>
    <Card className="flex-fill w-100">
      <Card.Header>
        <div className="card-actions float-end">
          <Dropdown align="end">
            <Dropdown.Toggle as="a" bsPrefix="-">
              <MoreHorizontal />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item>Action</Dropdown.Item>
              <Dropdown.Item>Another Action</Dropdown.Item>
              <Dropdown.Item>Something else here</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <Card.Title tag="h5" className="mb-0">
          Segment-Gender
        </Card.Title>
      </Card.Header>
      <Card.Body className="d-flex">
        <div className="align-self-center w-100">
          <div className="chart">
            <Bar data={data} options={options} />
          </div>
        </div>
      </Card.Body>
      </Card>
      </>
      );
  
};

export default BarChart;

import { Pie } from "react-chartjs-2";
import { Card, Dropdown, Table } from "react-bootstrap";

import { MoreHorizontal } from "react-feather";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSquare } from "@fortawesome/free-solid-svg-icons";
import React, { useState, useEffect } from "react";


import usePalette from "../../../hooks/usePalette";
import { getCSVDataByGender }  from '../../../services/Dashboard-Service';


const PieChart = () => {
  const palette = usePalette();
  const [labelName, setLabelName] = useState([]);
  const [genderCount, setGenderCount] = useState([]);


  useEffect(() => {
    let tempLabelArray = [];
    let tempGenderArray = [];
    getCSVDataByGender().then(res => {
      const groupByGenderList = res.data;
      groupByGenderList.map((value) => {
        tempLabelArray.push(value.gender);
        tempGenderArray.push(value.count);
      });
      setLabelName(tempLabelArray);
      setGenderCount(tempGenderArray);
    });
    }, []);

  const data = {
    labels: labelName,
    datasets: [
      {
        data: genderCount,
        backgroundColor: [
          palette.primary,
          palette.warning
        ],
        borderWidth: 5,
        borderColor: palette.white,
      },
    ],
  };

  const options = {
    maintainAspectRatio: false,
    cutoutPercentage: 70,
    legend: {
      display: false,
    },
  };

  return (
    <>
    <Card className="flex-fill w-100">
      <Card.Header>
        <div className="card-actions float-end">
          <Dropdown align="end">
            <Dropdown.Toggle as="a" bsPrefix="-">
              <MoreHorizontal />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item>Action</Dropdown.Item>
              <Dropdown.Item>Another Action</Dropdown.Item>
              <Dropdown.Item>Something else here</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <Card.Title tag="h5" className="mb-0">
          Gender
        </Card.Title>
      </Card.Header>
      <Card.Body className="d-flex">
        <div className="align-self-center w-100">
          <div className="py-3">
            <div className="chart chart-xs">
              <Pie data={data} options={options} />
            </div>
          </div>

          <Table className="mb-0">
            <thead>
              <tr>
                <th>Gender</th>
                <th className="text-end">Counts</th>
                {/* <th className="text-end">Value</th> */}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <FontAwesomeIcon icon={faSquare} className="text-primary" />{" "}
                  {labelName[0]}
                </td>
                <td className="text-end">{genderCount[0]}</td>
                {/* <td className="text-end text-success">+43%</td> */}
              </tr>
              <tr>
                <td>
                  <FontAwesomeIcon icon={faSquare} className="text-warning" />{" "}
                  {labelName[1]}
                </td>
                <td className="text-end">{genderCount[1]}</td>
                {/* <td className="text-end text-success">+13%</td> */}
              </tr>
              {/* <tr>
                <td>
                  <FontAwesomeIcon icon={faSquare} className="text-danger" />{" "}
                  E-mail
                </td>
                <td className="text-end">$ 541</td>
                <td className="text-end text-success">+24%</td>
              </tr>
              <tr>
                <td>
                  <FontAwesomeIcon icon={faSquare} className="text-dark" />{" "}
                  Other
                </td>
                <td className="text-end">$ 1465</td>
                <td className="text-end text-success">+11%</td>
              </tr> */}
            </tbody>
          </Table>
        </div>
      </Card.Body>
      </Card>
            </>

      );
};

export default PieChart;

import React, { useEffect , useState} from "react";

import { Card, Dropdown  , Button} from "react-bootstrap";
// import the progress bar
import StepProgressBar from 'react-step-progress';
// import the stylesheet
import 'react-step-progress/dist/index.css';

import { MoreHorizontal } from "react-feather";

import { RunningDagModel , GetCurrentRunningDagTaskInstanceStatus , GetOverAllDagRunStatus } from "../../../services/Dashboard-Service"

// let step4Content = <div className="mt-3"><h3>1438.6 MB</h3></div>;
// let testVar = null;
// let step3Content = <div></div>
let taskID = "";
// let step3Content = <div className="mt-3"><h3>1438.6 MB</h3></div>;


 
// setup step validators, will be called before proceeding to the next step
function step2Validator() {
  // return a boolean
        return true;
}
 
function step3Validator() {
  // return a boolean
        return true;

}
 
function onFormSubmit() {
  // handle the submit logic here
  // This function will be executed at the last step
  // when the submit button (next button in the previous steps) is pressed
}



const StepProgress = ({ dagId }) => {

  const [dag_ID, setDag_ID] = useState(dagId);
  
  
    function Intialized() {

      let iDiv = document.createElement('div');
      iDiv.className = 'dynamicDiv';
      // iDiv.setAttribute("style", "color: red; font-size: 14px; margin-top: 46px;")
      iDiv.innerHTML = taskID;
      document.getElementsByClassName('_2_g61')[0].appendChild(iDiv);

      document.querySelector('._hsN1w').click();

        RunningDagModel(dag_ID).then(res => {   // RunningDagModel
          document.querySelector('._hsN1w').click();
          const dagRunID = res.data.dag_run_id;
          let totalEntries = null;
          let successCount = 0;
          
          
          iDiv.innerHTML = "In-Progress";

          const overAllInterval = setInterval(function () {

            GetOverAllDagRunStatus(dag_ID, dagRunID).then(res => {   // GetOverAllDagRunStatus
              iDiv.innerHTML = res.data.state;
              if (res.data && res.data.state !== 'queued') {
              
              clearInterval(overAllInterval);

              const interval = setInterval(function () {

                GetCurrentRunningDagTaskInstanceStatus(dag_ID, dagRunID).then(res => {  // GetCurrentRunningDagTaskInstanceStatus
                  let dagInstanceList = [];
                  dagInstanceList = res.data.task_instances;
                  totalEntries = res.data.total_entries;

                  let successIterationCount = 0;
                  Object.entries(dagInstanceList).map((data) => {
                    if (data[1].state === 'running') {
                      taskID = data[1].task_id;
                      iDiv.innerHTML = taskID;
                    } else if (data[1].state === 'success') {
                      successIterationCount++;
                      if (successIterationCount <= successCount || successCount === 0) {
                        successCount++;
                      }
                    }
                  })
                });
               
                if (successCount === totalEntries) {
                  clearInterval(interval);
                  document.querySelector('._hsN1w').click();
                  iDiv.innerHTML = "Success";
                }
            
              }, 8000);
            }
            
          });
            }, 30000);

        
        });

    }
  
  
  useEffect(() => {
                // step3Content = <div className="mt-3"><h3>{ taskID }</h3></div>;
            },[]); 

  return (<Card className="flex-fill w-100">
    <Card.Header>
      <div className="card-actions float-end">
        <Dropdown align="end">
          <Dropdown.Toggle as="a" bsPrefix="-">
            <MoreHorizontal />
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item>Action</Dropdown.Item>
            <Dropdown.Item>Another Action</Dropdown.Item>
            <Dropdown.Item>Something else here</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
      {/* <Card.Title tag="h5" className="mb-0">
        TD-Bank
      </Card.Title> */}
      </Card.Header>

      <Card.Body className="text-center">
      <div>
      <Button
          key='1'
          variant="primary"
          className="btn-pill me-1 mb-1"
          onClick={Intialized}
          >
            Run Model
          </Button>
      </div>
      <div>
        <span style={{
          position: "relative",
          top: "210px",
          right: "80px"
        }}><h5>Status :</h5></span>
            
    
    <StepProgressBar 
      startingStep={0}
      onSubmit={onFormSubmit}
      steps={[
        {
          label: 'Step 1',
          subtitle: 'Data Loaded',
          name: 'step 1'
          //   content: step1Content
        },
        {
          label: 'Step 2',
          subtitle: 'Started Dag',
          name: 'step 2',
          //   content: step2Content,
          validator: step2Validator
        },
        {
          label: 'Step 3',
          subtitle: 'Running',
          name: 'step 3',
          // content: step3Content,
          validator: step3Validator
        },
         {
          label: 'Step 4',
          subtitle: 'Completed',
          name: 'step 4'
          // content: step4Content
        }
      ]}
        />
      </div>
        </Card.Body>
  </Card>
  )
};

export default StepProgress;

import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";


const AverageTransactionValueLineChart = () => {
  const palette = usePalette();

  const data = [
    {
      name: "Loyalty Member",
      data: [374,
        360,
        318,
        397,
        477,
        462,
        490,
        414,
        378,
        479,
        462,
        485]
    },
    {
      name: "Non Loyalty Member",
      data: [335,
        294,
        174,
        168,
        163,
        178,
        302,
        277,
        340,
        188,
        182,
        343],
    }
  ];

  const options = {
    chart: {
      zoom: {
        enabled: true,
      },
    },
    dataLabels: {
      enabled: true,
    },
    stroke: {
      width: [5, 7, 5],
      curve: "straight",
      dashArray: [0, 8, 5],
    },
    markers: {
      size: 0,
      style: "full", // full, hollow, inverted
    },
    xaxis: {
      categories: [
        "Jan-21",
        "Feb-21",
        "Mar-21",
        "Apr-21",
        "May-21",
        "Jun-21",
        "Jul-21",
        "Aug-21",
        "Sept-21",
        "Oct-21",
        "Nov-21",
        "Dec-21",
      ],
    },
    yaxis: [
      {
        title: {
          text: "ATV(USD)",
          style: {
            color: '#000000',
          }
        }
      }],
    tooltip: {
      y: [
        {
          title: {
            formatter: function (val) {
              return val ;
            },
          },
        },
        {
          title: {
            formatter: function (val) {
              return val ;
            },
          },
        }
      ],
    },
    grid: {
      borderColor: "#f1f1f1",
    },
    colors: [
      palette.primary,
      palette.danger
    ],
  };

  return (
    <Card className="w-100">
      <Card.Header>
        <Card.Title tag="h5" className="mb-2">Avg Transaction Value of Loyalty Members and Non-Members</Card.Title>
        <h6 className="card-subtitle text-muted">
          {/* The brand has lost 7% of the customer base in the current month(180 days inactivity).
          YOY customer retention stands for 75%.YOY customer lost stands at 15%. */}
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="line" height="350" />
        </div>
      </Card.Body>

    </Card>
  );
};

export default AverageTransactionValueLineChart;

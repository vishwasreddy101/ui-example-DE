import React from "react";
import { Helmet } from "react-helmet-async";
import InputMask from "react-input-mask";
import Select from "react-select";
import { Button, Card, Col, Container, Form, Row , Accordion} from "react-bootstrap";
import { CircularProgressbar  , buildStyles} from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import AverageTransactionValueLineChart from "./AverageTransactionValueLineChart";
import CustomerRevenueSegmentPieChart from "./CustomerRevenueSegmentPieChart";
import CustomerShareSegmentPieChart from "./CustomerShareSegmentPieChart";




const options = [
  { value: "allCustomers", label: "All Customers" },
  { value: "newCustomers", label: "New Customers" },
  { value: "churnedCustomers", label: "Churned Customers" },
];
const FormRow = () => (
  <Card>
    <Card.Header>
      {/* <Card.Title tag="h5">Filter Set</Card.Title> */}
      {/* <h6 className="card-subtitle text-muted">Bootstrap column layout.</h6> */}
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>From</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

          </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
            <Form.Label>To</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mb-3">
        {/* <Form.Label>Customer Segment</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Customer Segment..."
            />
        </Form.Group>
        <Form.Group className="mb-3">
        {/* <Form.Label>Select Campaign</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Campaign..."
              isMulti
            />
        </Form.Group>
        <Form.Group className="mb-3">
        {/* <Form.Label>Select Channels</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Channels..."              
              isMulti
            />
        </Form.Group>
        <Button variant="primary">Filter</Button>
      </Form>
    </Card.Body>
  </Card>
);
const CustomerLoyality = () => {
  const percentage = 66;
  
  return (<React.Fragment>
  <Helmet title="Campaign Layout" />
  <Container fluid className="p-0">
    <h1 className="h3 mb-3">Customer Loyalty</h1>
    <h6 className="card-subtitle text-muted mb-3">
    This dashboard provides the summary of customer retention and churn during the specified period for the customers.
    Churn is defined at the brand level based on the number of days it takes for a customer to make a repeat visit
        </h6>
    <Row>
      <Col lg="6">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0" className="bg-white">
          <Accordion.Header>Parameters</Accordion.Header>
          <Accordion.Body>
          <FormRow />
          </Accordion.Body>
        </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    <Row className="mt-5">
    <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Total Customers</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">234,543</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Loyalty Members</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">134,345</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2" >
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">% Loyalty Members</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">57.2%</span>

            </Card.Body>
          </Card>
        </Col> 
     
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">Total Sales (USD)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">$ 45 Mn</span>
            </Card.Body>
          </Card>
        </Col>  
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">% Loyalty Sales of Total </h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">82%</span>
            </Card.Body>
          </Card>
        </Col>  

        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">Avg Transaction Value (Members)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-2 mb-4">$ 245</span>
            </Card.Body>
          </Card>
        </Col>  

    </Row>
          <Row className="nowrap"> 

             <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
             <Row>
             <h1 className="h3 mb-3">Repeat Customers</h1>
            </Row> 
             <CircularProgressbar value={30} text={`${30}%`} />;
              </Col>
             <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
             <Row>
             <h1 className="h3 mb-3">Active Customers</h1>
             </Row>
             <CircularProgressbar value={60} text={`${60}%`}  styles={buildStyles({
    // Rotation of path and trail, in number of turns (0-1)
    rotation: 0.25,

    // Whether to use rounded or flat corners on the ends - can use 'butt' or 'round'
    strokeLinecap: 'butt',

    // Text size
    textSize: '16px',

    // How long animation takes to go from one percentage to another, in seconds
    pathTransitionDuration: 0.5,

    // Can specify path transition in more detail, or remove it entirely
    // pathTransition: 'none',

    // Colors
    pathColor: `rgba(62, 152, 199, ${percentage / 100})`,
    textColor: '#f88',
    trailColor: '#d6d6d6',
    backgroundColor: '#3e98c7',
  })} />;
             </Col>
             <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
              <Row>
             <h1 className="h3 mb-3">Loyalty Index</h1>
             </Row>
             <CircularProgressbar value={90} text={`${90}%`} />;
             </Col>
            </Row>
            <Row className="nowrap">
            <Col md="7" lg="12" className="col-xxl-6 d-flex mt-5">
             <AverageTransactionValueLineChart />
              </Col>
            </Row>
            <Row className="nowrap">
            <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <CustomerShareSegmentPieChart />
              </Col>
              <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <CustomerRevenueSegmentPieChart />
              </Col>
            </Row>
            
           </Container>
</React.Fragment>)
};

export default CustomerLoyality
import React from "react";
import { Helmet } from "react-helmet-async";
import InputMask from "react-input-mask";
import Select from "react-select";
import CustomerChurnChart from "./CustomerChurnChart"
import RevenueChurnChart from "./RevenueChurnChart"
import { Button, Card, Col, Container, Form, Row , Accordion} from "react-bootstrap";
import CustomerChurnedSegmentPieChart from "./CustomerChurnedSegmentPieChart";
import SegmentWiseSplitGroupChart from "./SegmentWiseSplitGroupChart";


const options = [
  { value: "allCustomers", label: "All Customers" },
  { value: "newCustomers", label: "New Customers" },
  { value: "churnedCustomers", label: "Churned Customers" },
];
const FormRow = () => (
  <Card>
    <Card.Header>
      {/* <Card.Title tag="h5">Filter Set</Card.Title> */}
      {/* <h6 className="card-subtitle text-muted">Bootstrap column layout.</h6> */}
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>From</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

          </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
            <Form.Label>To</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mb-3">
        <Form.Label>Customer Segment</Form.Label>
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Customer Segment..."  
              
            />
        </Form.Group>
        <Form.Group className="mb-3">
        <Form.Label>Select Campaign</Form.Label>
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Campaign..."  
              isMulti
            />
        </Form.Group>
        <Form.Group className="mb-3">
        <Form.Label>Select Channels</Form.Label>
            <Select
              options={options}
              className="text-muted"
              placeholder="Select Channels..." 
              isMulti
            />
        </Form.Group>
        <Button variant="primary">Filter</Button>
      </Form>
    </Card.Body>
  </Card>
);
const CustomerRetentionDetails = () => {
  return (<React.Fragment>
  <Helmet title="Campaign Layout" />
  <Container fluid className="p-0">
    <h1 className="h3 mb-3">Customer Retention</h1>
    <h6 className="card-subtitle text-muted mb-3">
    This dashboard provides the summary of customer retention and churn during the specified period for the customers.
    Churn is defined at the brand level based on the number of days it takes for a customer to make a repeat visit
        </h6>
    <Row>
      <Col lg="6">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0" className="bg-white">
          <Accordion.Header>Parameters</Accordion.Header>
          <Accordion.Body>
          <FormRow />
          </Accordion.Body>
        </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    <Row className="mt-5">
    <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Customer Base</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">234,543</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Churned Customers</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">10,434</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2" >
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">% Churn (Last Month)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">1.5%</span>

            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">% Churn (Current Month)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-2 mb-4">4.5%</span>
            </Card.Body>
          </Card>
        </Col>  

        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Revenue Loss</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">$ 12 Mn</span>
            </Card.Body>
          </Card>
        </Col>  
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Net Retention </h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-5 mb-4">3.8%</span>
            </Card.Body>
          </Card>
        </Col>  
    </Row>
          <Row className="nowrap"> 

             <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <CustomerChurnChart />
              </Col>
             <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <RevenueChurnChart />
             </Col>
            </Row>
            <Row className="nowrap">
            <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <CustomerChurnedSegmentPieChart />
              </Col>
              <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <SegmentWiseSplitGroupChart />
              </Col>
            </Row>
            
           </Container>
</React.Fragment>)
};

export default CustomerRetentionDetails
import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const CustomerChurnedSegmentPieChart = () => {
  const palette = usePalette();

  const data = [2.3,3.8,4.0,11.5];

  const options = {
    chart: {
      width: 380,
      type: 'pie',
    },
    labels: ['Platinum Tier', 'Gold Tier', 'Silver Tier', 'Bronze Tier'],
    responsive: [{
      breakpoint: 480,
      options: {
        chart: {
          width: 200
        },
        legend: {
          position: 'bottom'
        }
      }
    }],
    colors: [
        palette.primary,
        "#CC6600",
        "#343a4b",
        palette.warning
      ]
  };


  return (
    <Card className="w-100">
      <Card.Header>
        <Card.Title tag="h5">% Churned Customers from each Segment</Card.Title>
        {/* <h6 className="card-subtitle text-muted">

        </h6> */}
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="pie" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default CustomerChurnedSegmentPieChart;

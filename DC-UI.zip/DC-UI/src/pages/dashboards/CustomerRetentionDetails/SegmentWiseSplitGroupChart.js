import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const SegmentWiseSplitGroupChart = () => {
  const palette = usePalette();

  const data = [{
    name: "% Total Revenue Loss",
    data: ["4%","13%","26%","57%"]
  }, {
    name: "% of Total Churn",
    data: ["18%","29%","36%","18%"]
  }];

  const options = {
    chart: {
      type: 'bar',
      height: 430
    },
    plotOptions: {
      bar: {
        horizontal: true,
        dataLabels: {
          position: 'top',
        },
      }
    },
    dataLabels: {
      enabled: true,
      offsetX: -6,
      style: {
        fontSize: '12px',
        colors: ['#fff']
      }
    },
    stroke: {
      show: true,
      width: 1,
      colors: ['#fff']
    },
    tooltip: {
      shared: true,
      intersect: false
    },
    xaxis: {
      categories: ["Bronze Tier", "Silver Tier", "Gold Tier", "Platinum Tier"],
    },
    colors: [
        "#CC6600",
        palette.primary
      ]
  };



  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">Segment wise split of share of churned customers and revenue loss</Card.Title>
        {/* <h6 className="card-subtitle text-muted">
        </h6> */}
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="bar" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default SegmentWiseSplitGroupChart;

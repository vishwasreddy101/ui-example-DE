import React from "react";
import Chart from "react-apexcharts";
import { Card, Col, Row } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const CustomerChurnChart = () => {
  const palette = usePalette();

  const data = [
    {
      name: "Monthly Customers Churn Rate",
      data: [
        4.09,
        8.19,
        8.82,
        3.39,
        3.94,
        9.31,
        4.23,
        4.46,
        6.73,
        4.48,
        5.27,
        3.40]
    }
  ];

  const options = {
    chart: {
      zoom: {
        enabled: false,
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      width: [5, 7, 5],
      curve: "straight",
      dashArray: [0, 8, 5],
    },
    markers: {
      size: 0,
      style: "hollow", // full, hollow, inverted
    },
    xaxis: {
      categories: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "sept",
        "Oct",
        "Nov",
        "Dec",
      ],
    },
    tooltip: {
      y: [
        
        {
          title: {
            formatter: function (val) {
              return val;
            },
          },
        },
      ],
    },
    grid: {
      borderColor: "#f1f1f1",
    },
    colors: [
      palette.primary
    ],
  };

  return (
    <Card className="w-100">
      <Card.Header>
        <Card.Title tag="h5" className="mb-2">Customer Churn</Card.Title>
        {/* <h6 className="card-subtitle text-muted">
          The brand has lost 7% of the customer base in the current month(180 days inactivity).
          YOY customer retention stands for 75%.YOY customer lost stands at 15%.
        </h6> */}
      </Card.Header>
      <Card.Body>
      <Row className="mt-0">

    <Col lg="6">
      <Card className="flex-fill" style={{ backgroundColor: "grey"}}>
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title text-white">Last Month</h5>
                </Col>
              </Row>
              <Row>
              <span className="h2 d-inline-block mt-0 mb-0 text-white">1.5%(+3%)</span>
              </Row>
              <Row>
              <span className="h5 d-inline-block mt-0 mb-0 text-white">vs previous period</span>
              </Row>

            </Card.Body>
          </Card>
      </Col> 

     <Col lg="6">
      <Card className="flex-fill" style={{ backgroundColor: "grey"}}>
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title text-white">Total</h5>
                </Col>
              </Row>
              <span className="h2 d-inline-block mt-0 mb-0 text-white">16.8%</span>
              <Row>
              <span className="h5 d-inline-block mt-0 mb-0 text-white">Last 12 Months</span>
              </Row>

            </Card.Body>
          </Card>
      </Col> 

      </Row>
        <div className="chart">
          <Chart options={options} series={data} type="line" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default CustomerChurnChart;

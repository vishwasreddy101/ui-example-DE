import React from "react";
import { Helmet } from "react-helmet-async";
import { Container, Row } from "react-bootstrap";

// import Chart from "./Chart";
import Header from "./Header";
// import Markets from "./Markets";
// import Orders from "./Orders";
import ChurnDashboard from "./ChurnDashboard";

const Churn = () => (
  <React.Fragment>
    <Helmet title="Churn Dashboard" />
    <Container fluid className="p-0">
      <Header />
      <Row className="mt-5">
        <ChurnDashboard />
        </Row>
      {/* <Row>
        <Col lg="5" className="d-flex col-xxl-4">
          <Markets />
        </Col>
        <Col lg="7" className="d-flex col-xxl-8">
          <Chart />
        </Col>
      </Row>
      <Orders /> */}
    </Container>
  </React.Fragment>
);

export default Churn;

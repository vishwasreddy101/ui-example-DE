import React from "react";
import { Col,Form , Row, Container } from "react-bootstrap";
import Select from "react-select";
// import BarChart from "./BarChart";
// import PieChart from "./PieChart";
import StepProgress from "../Analytics/StepProgress"

const options = [
  { value: "databricks_dag", label: "databricks_dag" },
  { value: "databricks_iris_dag", label: "databricks_iris_dag" },
  { value: "my_dag", label: "my_dag" }
];



const ChurnDashboard = () => {
  const [showResults, setShowResults] = React.useState(false)
  const [showTrainResults, setShowTrainResults] = React.useState(false)
  const [dagId, setDagId] = React.useState(null)

  
const dagInputChange = (e) => {
  setDagId(e.value);
  }
  const onViewModelClick = () => {
    setShowResults(true);
    setShowTrainResults(false);

  }
  const onTrainModelClick = () => {
    setShowResults(false);
    setShowTrainResults(true);
  }

  return (
  <>              
    <Row>

      <Col md="6" xl>
        <div className="align-items-start">
          <button className="button" onClick={onViewModelClick}>
            View Model</button>
        </div>
      </Col>
      <Col md="6" xl>
        <div className="align-items-start">
          <button className="button" onClick={onTrainModelClick}>
            Train Model</button>
        </div>
      </Col>
      <Col md="2" xl>
        <div className="align-items-start">
          <button className="button">
            Score Data</button>
        </div>
      </Col>
      {showResults ? <Row>
        {/* <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
        <BarChart />
        </Col>
        <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
          <PieChart />
        </Col>
        <Col md="7" lg="4" className="col-xxl-6 d-flex mt-5">
          <LineChart />
        </Col> */}
      </Row> : null}

      {showTrainResults ? <Row>
        <Container>
          <div className="mt-5 text-center">
        Train Model by executing the Airflow Dag, Select and pass on the dataset location to the model
        </div>
        </Container>

           <div>
            <Row>
              <Col className="mt-5 col-sm-5">
            <Form.Group className="mb-3">
            <Form.Label>Data Location</Form.Label>
            <Select
              className="react-select-container"
              classNamePrefix="react-select"
              options={options}
              isSearchable
              onChange={dagInputChange}
            />
          </Form.Group>
            </Col>
            <Col lg="7" xl="8" className="d-flex">
              {dagId ? <StepProgress dagId={dagId} /> : <div></div>}
            </Col>
          </Row>
          </div>
         
      </Row> 
      : null}
    </Row>
    </>

  )
};

export default ChurnDashboard;

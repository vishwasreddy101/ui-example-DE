import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const NewAndChurnedCustomersChart = () => {
  const palette = usePalette();

  const data = [
    {
      name: "New Customers",
      type: "column",
      data: [
        42212,
        45367,
        21215,
        35132,
        16186,
        39139,
        37109,
        37070,
        30324,
        27343,
        37279,
        31793],
    },
    {
      name: "Churned Customer",
      type: "column",
      data: [
        11486,
        14334,
        13632,
        8968,
        9951,
        14496,
        7053,
        9552,
        10726,
        7604,
        9338,
        5857]
    },
    {
      name: "Total Customers",
      type: "line",
      data: [
        423997,
        454723,
        485756,
        493339,
        519503,
        525738,
        550381,
        580437,
        607955,
        627553,
        647292,
        675233],
    },
  ];

  var options = {
    series: [{
    name: 'NewCustomers',
    type: 'column'
    }, {
    name: 'ChurnedCustomers',
    type: 'column'
    }, {
    name: 'TotalCustomers',
    type: 'line',
  }],
    chart: {
    height: 350,
    type: 'line',
    stacked: false
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    width: [1, 1, 4]
  },
  // title: {
  //   text: 'XYZ - Stock Analysis (2009 - 2016)',
  //   align: 'left',
  //   offsetX: 110
  // },
  xaxis: {
    categories: ["Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"],
  },
  yaxis: [
    {
      seriesName: 'NewCustomers',
      axisTicks: {
        show: true,
      },
      axisBorder: {
        show: true,
        color: '#000000'
      },
      labels: {
        style: {
          colors: '#000000',
        }
      },
      title: {
        text: "New Customers",
        style: {
          color: '#000000',
        }
      },
      tooltip: {
        enabled: true
      }
    },
    {
      seriesName: 'TotalCustomers',
      opposite: true,
      axisTicks: {
        show: true,
      },
      axisBorder: {
        show: true,
        color: '#000000'
      },
      labels: {
        style: {
          colors: '#000000',
        },
      },
      title: {
        text: "Total Customers",
        style: {
          color: '#000000',
        }
      }
    },
  ],
  tooltip: {
    fixed: {
      enabled: true,
      position: 'topLeft', // topRight, topLeft, bottomRight, bottomLeft
      offsetY: 30,
      offsetX: 60
    },
  },
  legend: {
    horizontalAlign: 'left',
    offsetX: 40
  },
  colors: [
    "#CC6600",
    "#A9A9A9",
    palette.primary
  ],
  };

  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">New and Churned Customers
</Card.Title>
        <h6 className="card-subtitle text-muted">
          A Mixed Chart is a visualization that allows the combination of two or
          more distinct graphs.
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="line" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default NewAndChurnedCustomersChart;

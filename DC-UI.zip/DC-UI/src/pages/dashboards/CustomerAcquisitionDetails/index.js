import React from "react";
import { Helmet } from "react-helmet-async";
import InputMask from "react-input-mask";
import Select from "react-select";
import { Button, Card, Col, Container, Form, Row , Accordion} from "react-bootstrap";
import AgeGroupPieChart from "./AgeGroupPieChart";
import WorldMap from "./WorldMap";
import ColumnCustomerLifeTimeChart from "./ColumnCustomerLifeTimeChart";
import ColumnAgeGroupChart from "./ColumnAgeGroupChart";
import NewAndChurnedCustomersChart from "./NewAndChurnedCustomersChart";

const options = [
  { value: "allCustomers", label: "All Customers" },
  { value: "newCustomers", label: "New Customers" },
  { value: "churnedCustomers", label: "Churned Customers" },
];
const FormRow = () => (
  <Card>
    <Card.Header>
      {/* <Card.Title tag="h5">Filter Set</Card.Title> */}
      {/* <h6 className="card-subtitle text-muted">Bootstrap column layout.</h6> */}
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>From</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

          </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
            <Form.Label>To</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mb-3">
        {/* <Form.Label>Customer Segment</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Customer Segment..."
            />
        </Form.Group>
        <Button variant="primary">Filter</Button>
      </Form>
    </Card.Body>
  </Card>

  
);
const CustomerAcquisitionDetails = () => {
  return (<React.Fragment>
  <Helmet title="Campaign Layout" />
  <Container fluid className="p-0">
    <h1 className="h3 mb-3">Customer Acquisition</h1>
    <h6 className="card-subtitle text-muted mb-3">
    This dashboard provides the details of customer onboarded through multiple channels, 
    and change in active customers in different time periods
        </h6>
    <Row>
      <Col lg="6">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0" className="bg-white">
          <Accordion.Header>Parameters</Accordion.Header>
          <Accordion.Body>
          <FormRow />
          </Accordion.Body>
        </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    <Row className="mt-5">
    <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Total Customers</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">234,543</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">New Customers</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">34,345</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2" >
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Churned Customers</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">1,434</span>

            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Total Sales (USD)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">455 Million</span>
            </Card.Body>
          </Card>
        </Col>  

        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">% Sales New Customer</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-4 mb-4">12%</span>
            </Card.Body>
          </Card>
        </Col>  
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">% Sales Churned Customers </h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-1 mb-4">18%</span>
            </Card.Body>
          </Card>
        </Col>  
    </Row>
          <Row className="nowrap"> 

             <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <NewAndChurnedCustomersChart />
              </Col>
             <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
             <ColumnCustomerLifeTimeChart />
             </Col>
            </Row>
            <Row className="nowrap">
            <Col md="7" lg="12" className="col-xxl-6 d-flex mt-5">
             <WorldMap />
              </Col>
            </Row>
            <Row className="nowrap"> 

           <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
           <AgeGroupPieChart />
           </Col>
           <Col md="7" lg="6" className="col-xxl-6 d-flex mt-5">
           <ColumnAgeGroupChart />
           </Col>
           </Row>
           </Container>
</React.Fragment>)
};

export default CustomerAcquisitionDetails
import React from "react";
import { Pie } from "react-chartjs-2";

import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const AgeGroupPieChart = () => {
  const palette = usePalette();

  const data = {
    labels: ["Male", "Female"],
    datasets: [
      {
        data: [200000, 250000],
        backgroundColor: [
          palette.primary,
          palette.warning
        ],
        borderColor: "transparent",
      },
    ],
  };

  const options = {
    maintainAspectRatio: false,
    legend: {
      display: false,
    },
  };

  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">Gender Split of customers</Card.Title>
        <h6 className="card-subtitle text-muted">
          Pie charts are excellent at showing the relational proportions between
          data.
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart chart-sm">
          <Pie data={data} options={options} />
        </div>
      </Card.Body>
    </Card>
  );
};

export default AgeGroupPieChart;

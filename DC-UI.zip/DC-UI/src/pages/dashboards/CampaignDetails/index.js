import React from "react";
import { Helmet } from "react-helmet-async";
import InputMask from "react-input-mask";
import Select from "react-select";
import { Button, Card, Col, Container, Form, Row , Accordion} from "react-bootstrap";
// import { ArrowUpRight, Clock, Users } from "react-feather";
import BarChart from "./SegmentBar";
import SalesBarChart from "./SalesBar";
import AverageTransactionValueLineChart from "./AverageTransactionValueLineChart";
import IncrementalResponseBySegment from "./IncrementalResponseBySegment";




const options = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];
const FormRow = () => (
  <Card>
    <Card.Header>
      {/* <Card.Title tag="h5">Filter Set</Card.Title> */}
      {/* <h6 className="card-subtitle text-muted">Bootstrap column layout.</h6> */}
    </Card.Header>
    <Card.Body>
      <Form>
        <Row>
          <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>From</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

          </Form.Group>
          </Col>
          <Col md={6}>
            <Form.Group className="mb-3">
            <Form.Label>To</Form.Label>
            <InputMask mask="99/99/9999">
              {(inputProps) => <Form.Control {...inputProps} type="text" />}
            </InputMask>
           {/* <span className="text-muted">e.g "DD/MM/YYYY"</span> */}

            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mb-3">
        {/* <Form.Label>Customer Segment</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Customer Segment..."
            />
        </Form.Group>
        <Form.Group className="mb-3">
        {/* <Form.Label>Select Campaign</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Campaign..."
              isMulti
            />
        </Form.Group>
        <Form.Group className="mb-3">
        {/* <Form.Label>Select Channel</Form.Label> */}
            <Select
              classNamePrefix="react-select"
              options={options}
              className="text-muted"
              placeholder="Select Channel..."
              isMulti
            />
        </Form.Group>
        <Button variant="primary">Filter</Button>
      </Form>
    </Card.Body>
  </Card>

  
);
const CampaignDetails = () => {
  return (<React.Fragment>
  <Helmet title="Decision Engine" />
  <Container fluid className="p-0">
    <h1 className="h3 mb-3">Campaign Response</h1>
    <Row>
      <Col lg="6">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0" className="bg-white">
          <Accordion.Header>Parameters</Accordion.Header>
          <Accordion.Body>
          <FormRow />
          </Accordion.Body>
        </Accordion.Item>
        </Accordion>
      </Col>
    </Row>
    <Row className="mt-5">
    <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">Customer Base</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-3 mb-4">234,543</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title">Total Campaigns</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-3 mb-4">18</span>
            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2" >
    <Card className="flex-fill ellipsis ">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">% ROI (Current Month)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-0 mb-4">10.15%</span>

            </Card.Body>
          </Card>
        </Col> 
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">% ROI (Last Month)</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-3 mb-4">13.5%</span>
            </Card.Body>
          </Card>
        </Col>  

        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">Incremental Revenue</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-3 mb-4">$ 443k</span>
            </Card.Body>
          </Card>
        </Col>  
        <Col lg="2">
    <Card className="flex-fill ellipsis">
            <Card.Body>
              <Row>
                <Col className="mt-0">
                  <h5 className="card-title ">Incremental Response</h5>
                </Col>
              </Row>
              <span className="h1 d-inline-block mt-3 mb-4">8%</span>
            </Card.Body>
          </Card>
        </Col>  
    </Row>
    <hr />
    <div className="text-center my-4">
              <h2>Insight</h2>
            </div>
            <Row>
              <Col sm="6" md="5" className="ms-auto">
                <Card>
                  <Card.Body>
                    {/* <Card.Title tag="h5">
                      Do I need a credit card to sign up?
                    </Card.Title> */}
                    <p className="mb-0">
                      <b>Incremental sales(usd): 443,456</b><br/>
                         Test Group: 1.8 million<br/>
                         Control Group: 1.4 million<br/>
                      <b>Incremental Response(usd): 8%</b><br/>
                         Test Group: 14%<br/>
                         Control Group: 6%<br/>
                    </p>
                  </Card.Body>
                </Card>
              </Col>
              <Col sm="6" md="5" className="me-auto">
                <Card style={{height: "87%"}}>
                  <Card.Body>
                    {/* <Card.Title tag="h5">Do you offer a free trial?</Card.Title> */}
                    <p className="mb-0">
                    <b>ROI on Campaign: 10.15%</b><br/>
                       Incremental sales: $ 443,334<br/>
                       Campaign sales: $ 43,000<br/>
                    </p>
                  </Card.Body>
                </Card>
              </Col>
              </Row>
              <Row className="nowrap">
                <Col md="7" lg="12" className="col-xxl-6 d-flex mt-5">
                <AverageTransactionValueLineChart />
                </Col>
            </Row>
              <Row>
                <BarChart />
              </Row>
              <Row className="nowrap">

              <Col md="7" lg="12" className="col-xxl-6 d-flex mt-5">
             <IncrementalResponseBySegment />
              </Col>
              </Row>
              <Row>
                <SalesBarChart />
              </Row>
  </Container>
</React.Fragment>)
};

export default CampaignDetails
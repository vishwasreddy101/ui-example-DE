import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";


const AverageTransactionValueLineChart = () => {
  const palette = usePalette();

  const data = [
    {
      name: "Test Group Sales",
      data: [9101,
        9354,
        10156,
        11578,
        10876,
        11024,
        10068,
        11168,
        11493,
        10456,
        11712,
        11193,
        11850,
        10162,
        10397,
        12459,
        12411,
        12657,
        12231,
        12325,
        12987,
        12142,
        14199,
        14986,
        13481,
        14276,
        15573,
        14002,
        15395,
        14181]
    },
    {
      name: "Control Group Sales",
      data: [
        9192.01,
        9541.08,
        10257.56,
        11230.66,
        10984.76,
        12126.4,
        10168.68,
        11503.04,
        10688.49,
        10560.56,
        11829.12,
        10073.7,
        11968.5,
        10263.62,
        11332.73,
        11913,
        10740,
        10077,
        11822,
        10311,
        10714,
        11267,
        11167,
        10533,
        11591,
        11260,
        10055,
        11933,
        11333,
        10614
      ],
    }
  ];

  const options = {
    chart: {
      zoom: {
        enabled: true,
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      width: [5, 7, 5],
      curve: "straight",
      dashArray: [0, 8, 5],
    },
    markers: {
      size: 0,
      style: "full", // full, hollow, inverted
    },
    xaxis: {
      categories: [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28,
        29,
        30
      ],
    },
    yaxis: [
      {
        title: {
          text: "Total Sales(USD)",
          style: {
            color: '#000000',
          }
        }
      }],
    tooltip: {
      y: [
        {
          title: {
            formatter: function (val) {
              return val;
            },
          },
        },
        {
          title: {
            formatter: function (val) {
              return val;
            },
          },
        }
      ],
    },
    grid: {
      borderColor: "#f1f1f1",
    },
    colors: [
      palette.primary,
      palette.warning
    ],
  };

  return (
    <Card className="w-100">
      <Card.Header>
        <Card.Title tag="h5" className="mb-2">Incremental Sales: Test Group vs Control Group</Card.Title>
        <h6 className="card-subtitle text-muted">
          Campaign Period Normalized to 30 Days (Day 1-15: Pre Campaign, Day 16-30: Post Campaign)
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="line" height="350" />
        </div>
      </Card.Body>

    </Card>
  );
};

export default AverageTransactionValueLineChart;

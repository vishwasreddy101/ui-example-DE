import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const SalesBarChart = () => {
  const palette = usePalette();

  const data = [
    {
      name: "Facebook",
      data: [88600],
    },
    {
      name: "Google Adwords",
      data: [110750],
    },
    {
      name: "Other Social Media",
      data: [97460],
    },
    {
      name: "Email",
      data: [57590],
    },
    {
      name: "SMS",
      data: [66450],
    },
    {
      name: "Direct Mail",
      data: [22150],
    }
  ];

  const options = {
    chart: {
      stacked: true,
    },
    plotOptions: {
      bar: {
        horizontal: true,
      },
    },
    stroke: {
      width: 1,
      colors: ["#fff"],
    },
    xaxis: {
      categories: [2020],
      labels: {
        formatter: function (val) {
          return val + "K";
        },
      },
    },
    yaxis: {
      title: {
        text: undefined,
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return val + "K";
        },
      },
    },
    fill: {
      opacity: 1,
    },
    legend: {
      position: "top",
      horizontalAlign: "left",
      offsetX: 40,
    },
    colors: [
      palette.primary,
      palette.success,
      palette.warning,
      palette.danger,
      palette.info,
    ],
  };

  return (
    <Card>
      <Card.Header>
        <Card.Title tag="h5">Revenue Contribution by Channel</Card.Title>
        <h6 className="card-subtitle text-muted">
          A bar chart is the best tool for displaying comparisons between
          categories of data.
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="bar" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default SalesBarChart;

import React from "react";
import Chart from "react-apexcharts";
import { Card } from "react-bootstrap";

import usePalette from "../../../hooks/usePalette";

const IncrementalResponseBySegment = () => {
  const palette = usePalette();

  const data = [
    {
      name: "Test Group",
      data: [18,
        16,
        15,
        14],
    },
    {
      name: "Control Group",
      data: [6,
        8,
        7,
        10],
    }
  ];

  const options = {
    plotOptions: {
      bar: {
        horizontal: false,
        endingShape: "rounded",
        columnWidth: "55%",
        dataLabels: {
          position: 'top'
        }
      },
    },
   
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },
    xaxis: {
      categories: [
        "Platinum Tier",
        "Gold Tier",
        "Silver Tier",
        "Bronze Tier"
      ],
    },
    yaxis: {
      title: {
        text: "Incremental Response (Test vs Control)",
      },
    },
    fill: {
      opacity: 1,
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return val + "%";
        },
      },
    },
    colors: [
      palette.primary,
      "#CC6600"
    ],
  };

  return (
    <Card className="w-100">
      <Card.Header>
        <Card.Title tag="h5">Incremental Response by Segment</Card.Title>
        <h6 className="card-subtitle text-muted">
          {/* A column chart uses vertical bars to display data and is used to
          compare values across categories. */}
        </h6>
      </Card.Header>
      <Card.Body>
        <div className="chart">
          <Chart options={options} series={data} type="bar" height="350" />
        </div>
      </Card.Body>
    </Card>
  );
};

export default IncrementalResponseBySegment;


import React , { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import {
    Button,
    Card,
    Col,
    Container,
    Row,
    Modal,
    Form,
    Accordion} from "react-bootstrap";
import cltvPrediction from "../../assets/img/illustrations/cltv-prediction.png";
import decileSummary from "../../assets/img/illustrations/decile-summary.png";
import keyFeatures from "../../assets/img/illustrations/key-features.png";


import Select from "react-select";
// import MultiRangeSlider from "multi-range-slider-react";
import * as Icon from "react-feather";
import CSVFileReader from "../CSV-file-reader";
import {  saveNBAConfigRulesForm } from "../../services/NBA-Service";
// import { CSVLink } from "react-csv";
import StepProgress from "./StepProgress";



const selectModel = [

    { value: "Linear Regression", label: "Linear Regression" },
    { value: "Random Forest", label: "Random Forest"},
    { value: "XGBoost", label: "XGBoost" }
]

const selectEvaluationMetric =[
    { value: "Mean Absolute Error", label: "Mean Absolute Error (MAE)" },
    { value: "Mean Absolute Percentage", label: "Mean Absolute Percentage" }

]



const ConfigurationSection = () => {

    const [addDataModal,setAddDataModal] = useState(false);
    const [modelParameters,setModelParameters] = useState(false);
    const [selectModal,setSelectModal] = useState(false);
    
    // ------->
    const [hcpSpecialityCurrentValue,setHCPSpecialityCurrentValue] = useState("");
    const [availableChannels,setAvailableChannels] = useState("");

    


    const [minValue, set_minValue] = useState(25);
    const [maxValue, set_maxValue] = useState(75);

    const [CSVData,setCSVData] = useState([]);


    useEffect(() => {
    //   getNBAConfigRulesFormData().then((res) => {
    //     if (res.data) {
    //      setHCPSpecialityCurrentValue(res.data["hcpSpeciality"]);
    //      setAvailableChannels(res.data["availableChannels"]);
         
    //   }
    // });

    },[]);

    const handleInput = (e) => {
        set_minValue(e.minValue);
        set_maxValue(e.maxValue);
      };
      const handleSubmit = (e) => {
        e.preventDefault();

        const formData = {"hcpSpeciality": hcpSpecialityCurrentValue,
                           "availableChannels": availableChannels}

        saveNBAConfigRulesForm(formData).then((res) => {
                            if (res.data) {
                             
                             
                          }
                        });
      
      }

    return(<>
      <Card>
    <Card.Body className="text-center"></Card.Body>
      <Row >
          <Col lg="4" >
          <div className=" justify-content-center m-3">
          <Button
            variant={`outline-primary`}
            style={{padding:"29px 85px"}}
            onClick={()=> setAddDataModal(true)    
            }
          >
              Add Data
          </Button>
      </div>
      </Col>
      <Col lg="4" >
      <div className=" justify-content-center m-3">
          <Button
            variant={`outline-primary`}
            style={{padding:"30px 69px"}}
            onClick={()=> setModelParameters(true)    
            }
          >
              Model Parameters
          </Button>
      </div>
      </Col>
      <Col lg="4" >
      <div className=" justify-content-center m-3">
          <Button
            variant={`outline-primary`}
            style={{padding:"29px 78px"}}
            onClick={()=> setSelectModal(true)    
            }
           >
            Select Model
          </Button>
      </div>
      </Col>
      </Row>

      {selectModal ? 
      
      <Form>
         <Modal show={selectModal} onHide={selectModal}>
        <Modal.Header>
        <Modal.Title>Select Model</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        
            <Row className="mt-3">
            <Col lg="6"> 
            <Select
              classNamePrefix="react-select"
              options={selectModel}
              value={availableChannels}
              className="text-muted"
              onChange={changeEvent => setAvailableChannels(changeEvent)}
              placeholder="Select Model ..."
              isMulti
           />
        
            </Col>
           
           </Row>
           <Row className="mt-3">
           <Col lg="6"> 
            <Select
              classNamePrefix="react-select"
              options={selectEvaluationMetric}
              value={availableChannels}
              className="text-muted"
              onChange={changeEvent => setAvailableChannels(changeEvent)}
              placeholder="Select Evaluation Metrics ..."
              isMulti
           />
            </Col>
           </Row>   
           </Modal.Body>
          <Modal.Footer>
        <Button  onClick={()=>setSelectModal(false)}>Save</Button>
        <div style={{marginRight:"13%",marginLeft:"16%"}}> <Icon.Download /> Download Rules Configuration in CSV </div>
        <Button onClick={()=>setSelectModal(false)}>Close</Button>
      </Modal.Footer>
       </Modal>
     </Form>
        

      : <div></div>}

      {modelParameters ? 
      
       <Form>
          <Modal show={modelParameters} onHide={modelParameters}>
         <Modal.Header>
         <Modal.Title>Model Parameters</Modal.Title>
       </Modal.Header>
       <Modal.Body>
         
             <Row className="mt-3">
             <Col lg="4">
             <label for="birthday">Training Time Period :</label>
             </Col>
             <Col lg="4">
             <label for="birthday">From :</label>
             <input type="date" id="from" name="from"/>
             </Col>
             <Col lg="4">
             <label for="birthday">to :</label>
             <input type="date" id="to" name="to"/>
             </Col>
            
            </Row>
            <Row className="mt-3">
            <Col lg="4">
             <label for="birthday">Validation Time Period :</label>
             </Col>
             <Col lg="4">
             <label for="birthday">From :</label>
             <input type="date" id="from" name="from"/>
             </Col>
             <Col lg="4">
             <label for="birthday">to :</label>
             <input type="date" id="to" name="to"/>
             </Col>
            </Row>   
            </Modal.Body>
           <Modal.Footer>
         <Button  onClick={()=>setModelParameters(false)}>Save</Button>
         <div style={{marginRight:"13%",marginLeft:"16%"}}> <Icon.Download /> Download Rules Configuration in CSV </div>
         <Button onClick={()=>setModelParameters(false)}>Close</Button>
       </Modal.Footer>
        </Modal>
      </Form>
         

       : <div></div>}

     {addDataModal ? 
       <Modal show={addDataModal} onHide={addDataModal}>
       <Modal.Header>
         <Modal.Title>Add Data</Modal.Title>
       </Modal.Header>
       <Modal.Body>
       <Form>
           <Row className="mt-3">
             <Col style={{marginLeft:"25%"}} slg="6"> 
             <h5>Upload Transaction Data</h5>
             <CSVFileReader setCSVData={setCSVData} />
             <Form.Control className="mt-2" type="text" name="input" style={{width:"68%"}} placeholder="Provide URL of the DataSource " />
             <Button className="mt-2" variant="primary">
             <Icon.Database /> Connect to DataBase
             </Button>

            </Col>

          </Row>
            

        </Form>
         

       </Modal.Body>
       <Modal.Footer>
         <Button style={{marginRight:"55%"}} onClick={()=>setAddDataModal(false)}>Save Data Location</Button>
         {/* <div style={{marginRight:"13%",marginLeft:"16%"}}> <Icon.Download /> Download Rules Configuration in CSV </div> */}
         <Button onClick={()=>setAddDataModal(false)}>Reset form</Button>
       </Modal.Footer>
     </Modal> : <div></div>}    
      </Card>
    
    </>);

}

const CustomerLifetimeValidation = () => {


return(<React.Fragment>
    <Helmet title="Campaign Layout" />
    <Container fluid className="p-0">
      <h1 className="h3 mb-3">Customer Life Time Value </h1>
      <h6 className="card-subtitle text-muted mb-3">
      Reach your customers at 1:1 personalisation using right channel,right content,right offer at the right time
      .Improve your ROI by 3x and generate a fullfilling and rewarding customer journey for each customer </h6>
      <Row className="justify-content-center">
        <Col lg="12">
        <Accordion >
          <Accordion.Item eventKey="0" className="bg-white">
            <Accordion.Header>Filters</Accordion.Header>
            <Accordion.Body>
            <ConfigurationSection />
            </Accordion.Body>
          </Accordion.Item>
          </Accordion>
        </Col>
      </Row>
      <Row  className="m-3">
      <Col lg="12">
      <StepProgress/>
      </Col>
      </Row>
      <Row className="mt-3">
      <img
                      className="img-fluid"
                      src={cltvPrediction}
                      alt="4r"
                    />
      </Row>
      <Row className="mt-3">
      <img
                      className="img-fluid"
                      src={decileSummary}
                      alt="4r"
                    />
      </Row>
      <Row className="mt-3">
      <img
                      className="img-fluid"
                      src={keyFeatures}
                      alt="4r"
                    />
      </Row>
      </Container>
      </React.Fragment>
      );
};

export default CustomerLifetimeValidation;

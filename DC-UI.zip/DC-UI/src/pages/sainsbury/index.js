import React, { useState, useEffect } from 'react';
import { Card,Col,Row,Container, Table, Form} from "react-bootstrap";
import RangeSlider from 'react-bootstrap-range-slider';
import { Button} from "react-bootstrap";

import { filterSainsburyData } from '../../services/Sainsbury-Service'
import { Helmet } from "react-helmet-async";
import Select from "react-select";

// import {  testData } from "./data.js";



function Sainsbury() {

  const [sainsburyResult,setSainsburyResult] = useState(null);


  const [number_of_channels , setNumber_of_channels] = useState(0);
  const [total_HHs , setTotal_HHs] = useState(0);
  const [reach_ch1 , setReach_ch1] = useState(0);
  const [reach_ch2 , setReach_ch2] = useState(0);
  const [reach_ch3 , setReach_ch3] = useState(0);
  const [reach_ch4 , setReach_ch4] = useState(0);


  const [cost_channel_1 , setCost_channel_1] = useState(0);
  const [cost_channel_2 , setCost_channel_2] = useState(0);
  const [cost_channel_3 , setCost_channel_3] = useState(0);
  const [cost_channel_4 , setCost_channel_4] = useState(0);
  const [dynamic_times_exposed , setDynamic_times_exposed] = useState(0);

  const submitFormfunction = () => {
    const sainsburyRequest = {
      "number_of_channels" : Number(number_of_channels),
      "Total_HHs" : Number(total_HHs),
      "reach_ch1" : Number(reach_ch1 / 100),
      "reach_ch2" : Number(reach_ch2 / 100),
      "reach_ch3" : Number(reach_ch3 / 100),
      "reach_ch4" : Number(reach_ch4 / 100),
      "Cost_channel_1" : Number(cost_channel_1),
      "Cost_channel_2" : Number(cost_channel_2),
      "Cost_channel_3" : Number(cost_channel_3),
      "Cost_channel_4" : Number(cost_channel_4),
      "dynamic_times_exposed": Number(dynamic_times_exposed)
    }
    filterSainsburyData(sainsburyRequest).then(res =>{
      if(res.data){
        setSainsburyResult(eval(res.data));
      }
    });  
 }
  

  useEffect(() => {
  }, []);


  const channels = [
    { value: 1, label: "Channel - 1" },
    { value: 2 , label: "Channel - 2" },
    { value: 3 , label: "Channel - 3" },
    { value: 4 , label: "Channel - 4" },
    // { value: 5 , label: "Channel - 5" }

  ];
  
  return (
    <>
      <React.Fragment>
    <Row>
      <Col lg="6">
      <Card className="mt-3">
      <Card.Header>
          <Card.Title tag="h5">Data CoE Modified Sainsbury Reach Simulator....</Card.Title>
          {/* <h6 className="card-subtitle text-muted">
            Column filtering by react-table
          </h6> */}
        </Card.Header>
        <Card.Body>
    <form>

    <Row>
      <label className="my-lg-4" htmlFor="number_of_channels">Please Select No of Channels</label>
      <Col lg="8">
      <Select
              classNamePrefix="react-select"
              options={channels}
              className="text-muted"
              onChange={changeEvent => setNumber_of_channels(changeEvent.value)}
              placeholder="Select Channels..."
            />
      </Col>
      </Row>

      <Row>
      <label className="my-lg-4" htmlFor="Total_HHs">HouseHold</label>
      <Col lg="8">
      <RangeSlider
        id="Total_HHs"
        name="Total_HHs"
        min={0}
        max={50000000}
        tooltipPlacement='top'
        onChange={val => 
          setTotal_HHs(val.target.value)
      }
      value={total_HHs}
      />
      </Col>
  
        <Col lg="4">
          <Form.Control 
          onChange={val => 
          setTotal_HHs(val.target.value)
          }  
          value={total_HHs}/>
        </Col>
      </Row>

      { number_of_channels >= 1 ? 
      <Row>
      <label className="my-lg-4" htmlFor="reach_ch1">Channel Reach 01 %</label>
      <Col lg="8">
      <RangeSlider
        id="reach_ch1"
        name="reach_ch1"
        min={0}
        max={100}
        step={1}
        tooltipPlacement='top'
        onChange={val => 
          setReach_ch1(val.target.value )
      }
      value={reach_ch1}
      />
      </Col>
      <Col lg="4">
          <Form.Control   
           id="reach_ch1"  
           onChange={val => 
          setReach_ch1(val.target.value )
           }
           value={reach_ch1}/>
           </Col>

      </Row>
      : <Row></Row>}

    { number_of_channels >= 2 ? 
      <Row>
      <label className="my-lg-4" htmlFor="reach_ch2">Channel Reach 02 %</label>
      <Col lg="8">
      <RangeSlider
        id="reach_ch2"
        name="reach_ch2"
        min={0}
        max={100}
        step={1}
        tooltipPlacement='top'
        onChange={val => 
          setReach_ch2(val.target.value )
      }
      value={reach_ch2}
      />
      </Col>
      <Col lg="4">
          <Form.Control  
           onChange={val => 
            setReach_ch2(val.target.value )
        }
          value={reach_ch2}/>
        </Col>
      </Row>
      : <Row></Row>}

      { number_of_channels >= 3 ? 

      <Row>
      <label className="my-lg-4" htmlFor="reach_ch3">Channel Reach 03 %</label>
      <Col lg="8">
      <RangeSlider
        id="reach_ch3"
        name="reach_ch3"
        min={0}
        max={100} 
        step={1}
        tooltipPlacement='top'
        onChange={val => 
          setReach_ch3(val.target.value )
        }
        value={reach_ch3}
      />
      </Col>
      <Col lg="4">
          <Form.Control  
           onChange={val => 
            setReach_ch3(val.target.value )
           }  
          value={reach_ch3} />
        </Col>
      </Row>
      : <Row></Row>}

      { number_of_channels >= 4 ? 

      <Row>
      <label className="my-lg-4" htmlFor="reach_ch4">Channel Reach 04 %</label>
      <Col lg="8">
      <RangeSlider
        id="reach_ch4"
        name="reach_ch4"
        min={0}
        max={100} 
        step={1}
        tooltipPlacement='top'
        onChange={val => 
          setReach_ch4(val.target.value )
        }
        value={reach_ch4}
      />
      </Col>
      <Col lg="4">
          <Form.Control  
          
          onChange={val => 
            setReach_ch4(val.target.value)
          }
          value={reach_ch4} />
        </Col>
      </Row>
      : <Row></Row>}

     { number_of_channels >= 1 ? 
      <Row>
      <label className="my-lg-4" htmlFor="Cost_channel_1">Cost Reach 01 $</label>
      <Col lg="8">
      <RangeSlider
        id="Cost_channel_1"
        name="Cost_channel_1"
        min={0}
        max={1000000}
        tooltipPlacement='top'
        onChange={val => setCost_channel_1(val.target.value)}
        value={cost_channel_1}
      />
      </Col>
      <Col lg="4">
          <Form.Control 
           onChange={val => 
            setCost_channel_1(val.target.value)
          }
          value={cost_channel_1} />
        </Col>
      </Row>
      : <Row></Row>}

      { number_of_channels >= 2 ? 
      <Row>
      <label className="my-lg-4" htmlFor="Cost_channel_2">Cost Reach 02 $</label>
      <Col lg="8">
      <RangeSlider
        id="Cost_channel_2"
        name="Cost_channel_2"
        min={0}
        max={1000000}
        tooltipPlacement='top'
        onChange={val => setCost_channel_2(val.target.value)}
        value={cost_channel_2}
      />
      </Col>
      <Col lg="4">
          <Form.Control  
          onChange={val => setCost_channel_2(val.target.value)}
          value={cost_channel_2} />
        </Col>
      </Row>
      : <Row></Row>}

      { number_of_channels >= 3 ? 
      <Row>
      <label className="my-lg-4" htmlFor="Cost_channel_3">Cost Reach 03 $</label>
      <Col lg="8">
      <RangeSlider
        id="Cost_channel_3"
        name="Cost_channel_3"
        min={0}
        max={1000000}
        tooltipPlacement='top'
        onChange={val => setCost_channel_3(val.target.value)}
        value={cost_channel_3}
      />
      </Col>
      <Col lg="4">
          <Form.Control  
          onChange={val => setCost_channel_3(val.target.value)}
          value={cost_channel_3} />
        </Col>
      </Row>
      : <Row></Row>}

      { number_of_channels >= 4 ? 
      <Row>
      <label className="my-lg-4" htmlFor="Cost_channel_4">Cost Reach 04 $</label>
      <Col lg="8">
      <RangeSlider
        id="Cost_channel_4"
        name="Cost_channel_4"
        min={0}
        max={1000000}
        tooltipPlacement='top'
        onChange={val => setCost_channel_4(val.target.value)}
        value={cost_channel_4}
      />
      </Col>
      <Col lg="4">
          <Form.Control  value={cost_channel_4}
          onChange={val => setCost_channel_4(val.target.value)}
          />
        </Col>
      </Row>
      : <Row></Row>}
      <Row>
      <label className="my-lg-4" htmlFor="dynamic_times_exposed">dynamic_times_exposed</label>

      <Col lg="8">
      <RangeSlider
        id="dynamic_times_exposed"
        name="dynamic_times_exposed"
        min={0}
        max={10}
        tooltipPlacement='top'
        onChange={val => setDynamic_times_exposed(val.target.value)}
        value={dynamic_times_exposed}
      />
      </Col>
      <Col lg="4">
          <Form.Control  value={dynamic_times_exposed}
          onChange={val => setDynamic_times_exposed(val.target.value)}
          />
        </Col>
      </Row>
      <Button onClick={submitFormfunction} >Simulate</Button>
    </form>
    </Card.Body>
     </Card>
     </Col>
   
    <Col style={{marginTop:"15px"}}>
    { sainsburyResult &&
     <div><Helmet title="Column Filtering" />
    <Container fluid className="p-0">
    <Table bordered>
      <thead>
        <tr>
          <th style={{ width: "10%" }}>Index</th>
          <th style={{ width: "40%" }}>Name</th>
          <th style={{ width: "25%" }}>Value</th>
        </tr>
      </thead>
      <tbody>
        { Object.entries(sainsburyResult).map(([index,item]) => {
       return (  
       <tr key={index}>
          <td>{index}</td>
          <td>{item.Name}</td>
          <td>{item.Value}</td>



        </tr>
       );
        })}
      </tbody>
    </Table>
    </Container>
    </div>}
    </Col>
    </Row>

    </React.Fragment>
    </>
  );
}

export default Sainsbury

import React from "react";
import { Helmet } from "react-helmet-async";
import { Container, Row, Carousel } from "react-bootstrap";

import unsplash1 from "../../assets/img/photos/ai-image.jpg";
import unsplash2 from "../../assets/img/photos/pipeline.jpg";
import unsplash3 from "../../assets/img/photos/ml-image.jpg";

const WithCaptions = () => {
  return (
        <Carousel>
          <Carousel.Item>
            <img className="w-100" src={unsplash1} alt="First slide" />
            <Carousel.Caption>
              <h3 className="text-white">AI Models</h3>
              <p>Run Advanced Artificial Intelligence models in the cloud.</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img className="w-100" src={unsplash2} alt="Second slide" />
            <Carousel.Caption>
              <h3 className="text-white">Model Pipeline</h3>
              <p>Integrate model pipelines and notebooks without backend.</p>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img className="w-100" src={unsplash3} alt="Third slide" />

            <Carousel.Caption>
              <h3 className="text-white">Machine Learning Models</h3>
              <p>
              Train, score, and deploy advanced Machine Learning Models.
              </p>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
  );
};

const CarouselComponent = () => (
  <React.Fragment>
    <Helmet title="Carousel" />
    <Container fluid className="text-center">
      <Row className="justify-content-center">
          <WithCaptions />
      </Row>
    </Container>
  </React.Fragment>
);

export default CarouselComponent;

import React, { useEffect , useState } from "react";

import {
  Badge,
  Button,
  Container,
  Col,
  Row,
  Nav,
  Navbar,
  Modal
} from "react-bootstrap";
import Carousel from "./Carousel";
import SignIn from "../auth/SignIn";
import * as Icon from "react-feather";


import {
  SIDEBAR_POSITION,
  SIDEBAR_BEHAVIOR,
  LAYOUT,
  THEME,
} from "../../constants";

import useTheme from "../../hooks/useTheme";
import useSidebar from "../../hooks/useSidebar";
import useLayout from "../../hooks/useLayout";
import Footer from "../../components/Footer"

import { ReactComponent as Logo } from "../../assets/img/logo.svg";






const Navigation = () => {

  const  [ modelState , setModelState ] = useState(false);

  useEffect(() => {
   
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });

  
  
  return (
  <>
  <Navbar>
    <Container>
      <Navbar.Brand className="landing-brand" href="/">
        <Logo/> <span 
        style={{
          color:"skyblue"
        }}> Decision{" "} </span>
        <Badge as="sup" bg="" className="badge-soft-primary p-1">
          Engine
        </Badge>
      </Navbar.Brand>
      <Nav className="ms-auto" navbar>
        <Nav.Item className="d-none d-md-inline-block">
          <Nav.Link
            href="/dashboard/default"
            target="_blank"
            rel="noreferrer"
            active
            className="text-lg px-lg-3"
            style={{
              color:"white"
            }}
          >
            Home
          </Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link
            href="/docs/introduction"
            target="_blank"
            rel="noreferrer"
            active
            className="text-lg px-lg-3"
            style={{
              color:"white"
            }}
          >
            Documentation
          </Nav.Link>
        </Nav.Item>
        <Nav.Item className="d-none d-md-inline-block">
          <Nav.Link
            href="mailto:visreddy3@publicis.groupe.net"
            active
            className="text-lg px-lg-3"
            style={{
              color:"white"
            }}
          >
            Contact
          </Nav.Link>
        </Nav.Item>
      </Nav>
      <Button
        data-toggle="modal" 
        data-target="#exampleModal"
        rel="noopener noreferrer"
        variant="success"
        className="ms-2"
        size="lg"
        onClick={() => setModelState(true)}
      >
        Login
      </Button>
    </Container>
  </Navbar>

      <Modal show={modelState} onHide={() => setModelState(false)}>  
          {/* <Modal.Header closeButton>This is a Modal Heading</Modal.Header>   */}
          <Modal.Body>
          <SignIn />
          </Modal.Body>  
          {/* <Modal.Footer>  
            <Button onClick={() => setModelState(false)}>Close</Button>  
            <Button onClick={() => setModelState(false)}>Save</Button>  
          </Modal.Footer>   */}
      </Modal>  
</>
);
};


const Landing = () => {
  const { setTheme } = useTheme();
  const { setPosition, setBehavior } = useSidebar();
  const { setLayout } = useLayout();
  useEffect(() => {
    setTheme(THEME.DEFAULT);
    setPosition(SIDEBAR_POSITION.LEFT);
    setBehavior(SIDEBAR_BEHAVIOR.STICKY);
    setLayout(LAYOUT.FLUID);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <React.Fragment>
      <Container fluid className="p-0">
      <Navigation />
      <Row>
      <Col  className="d-flex">
      <div  className="justify-content-start text-white  text-gradient m-6">
      <h3><Icon.Cpu />  Run Advanced Artificial Intelligence models in the cloud</h3><br/>
        <h3><Icon.Minimize2 /> Integrate model pipelines and notebooks without backend</h3> <br/>
        <h3><Icon.Power />  Train, score, and deploy advanced Machine Learning Models</h3>
      </div>
      </Col>
        <Col  className="d-flex  smallCarouselWindowCssSetting">
      <Carousel/>
       </Col>
      </Row>
      <Footer/>
      </Container>
    </React.Fragment>
  );
};

export default Landing;


import React from "react";
import { CSVReader } from "react-papaparse";
import * as Icon from "react-feather";


const buttonRef = React.createRef();

const CSVFileReader = ( { setCSVData }) => {
  const handleOpenDialog = (e) => {
    // Note that the ref is set async, so it might be null at some point
    if (buttonRef.current) {
      buttonRef.current.open(e);
    }
  };

  const handleOnFileLoad = (data) => {
    console.log("---------------------------");
    // console.log(data);
    // Remove the empty object on the end of the array:
    data.pop();
    setCSVData(data);
    console.log("---------------------------");
  };

  const handleOnError = (err, file, inputElem, reason) => {
    console.log("---------------------------");
    console.log(err);
    console.log("---------------------------");
  };

  const handleOnRemoveFile = (data) => {
    console.log("---------------------------");
    console.log(data);
    console.log("---------------------------");
  };

  const handleRemoveFile = (e) => {
    // Note that the ref is set async, so it might be null at some point
    if (buttonRef.current) {
      buttonRef.current.removeFile(e);
    }
  };

  return (
    <>
      {/* <h4>Upload your rules config CSV file</h4> */}
      <CSVReader
        ref={buttonRef}
        onFileLoad={handleOnFileLoad}
        onError={handleOnError}
        noClick
        noDrag
        config={{ header: true }}
        onRemoveFile={handleOnRemoveFile}
      >
        {({ file }) => (
          <>
            <br/>
             { file ? <div>
              {file && file.name}
              <span className="mx-2">
              <Icon.XCircle
              className="me-1 mb-1"
              onClick={handleRemoveFile}
              />
              </span>
              </div> : <div>No File Uploaded</div> 
              
              }
              
            <br/>
            <Icon.Upload
              onClick={handleOpenDialog}
              className="me-1 mb-1"
              variant={`outline-primary`}

            />
              Upload 
          </>
        )}
      </CSVReader>
    </>
  );
};

export default CSVFileReader;

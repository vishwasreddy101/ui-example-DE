import {
  Sliders,
  Users
} from "react-feather";

const pagesSection = [
  {
    href: "/dashboard",
    icon: Sliders,
    title: "Dashboards",
    badge: "5",
    children: [
      {
        href: "/dashboard/default",
        title: "Default",
      },
      {
        href: "/dashboard/analytics",
        title: "Analytics",
      },
      {
        href: "/dashboard/churn",
        title: "Churn",
      },
      {
        href: "/dashboard/cltv",
        title: "CLTV",
      },
      {
        href: "/dashboard/customer-journey",
        title: "Customer Journey",
      },
      {
        href: "/dashboard/rules-engine",
        title: "Rules Engine",
      },
      {
        href: "/dashboard/nba",
        title: "Next Best Action",
      },
      {
        href: "/dashboard/sales",
        title: "Sales",
      },
      {
        href: "/dashboard/sainsbury",
        title: "Sainsbury",
      }
      
    ],
  },
  {
    href: "/auth",
    icon: Users,
    title: "Auth",
    children: [
      {
        href: "/auth/sign-in",
        title: "Sign In",
      },
      {
        href: "/auth/sign-up",
        title: "Sign Up",
      },
      {
        href: "/auth/reset-password",
        title: "Reset Password",
      },
      {
        href: "/auth/404",
        title: "404 Page",
      },
      {
        href: "/auth/500",
        title: "500 Page",
      },
    ],
  }
];

const dashboardItems =  [
  {
    title: "Pages",
    pages: pagesSection,
  }
];

export default dashboardItems;


import { Dropdown } from "react-bootstrap";

import { PieChart, Settings, User } from "react-feather";

const NavbarUser = () => {
  let avatar = "Avatar0";
  if(localStorage.getItem('id')) {
   avatar = "Avatar" +localStorage.getItem('id');
  } 
  return (
    <Dropdown className="nav-item" align="end">
      <span className="d-inline-block d-sm-none">
        <Dropdown.Toggle as="a" className="nav-link">
          <Settings size={18} className="align-middle" />
        </Dropdown.Toggle>
      </span>
      <span className="d-none d-sm-inline-block">
        <Dropdown.Toggle as="a" className="nav-link">
          <img
            src={require(`../../assets/img/avatars/${avatar}.jpeg`).default}
            className="avatar img-fluid rounded-circle me-1"
            alt="avatar"
          />
          <span className="text-dark">{localStorage.getItem('userName')}</span>
        </Dropdown.Toggle>
      </span>
      <Dropdown.Menu drop="end">
        <Dropdown.Item>
          <User size={18} className="align-middle me-2" />
          Profile
        </Dropdown.Item>
        <Dropdown.Item>
          <PieChart size={18} className="align-middle me-2" />
          Analytics
        </Dropdown.Item>
        <Dropdown.Divider />
        <Dropdown.Item>Settings & Privacy</Dropdown.Item>
        <Dropdown.Item>Help</Dropdown.Item>
        <Dropdown.Item>Sign out</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default NavbarUser;

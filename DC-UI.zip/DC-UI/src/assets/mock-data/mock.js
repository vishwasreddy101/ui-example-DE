const employees = require('./employees.json');
const getDagTaskList = require('./getDagTaskList.json');
const runDagModel = require('./runDagModel.json');
const customer_journey_data = require('./customer_journey_data.json');
const predictive_test_data = require('./predictive_test.json');

module.exports = () => ({
    employees: employees,
    getDagTaskList: getDagTaskList,
    runDagModel: runDagModel,
    customerJourneyData: customer_journey_data,
    predictive_test_data:predictive_test_data
});
import React from "react";

// All pages that rely on 3rd party components (other than Bootstrap) are
// loaded asynchronously, to keep the initial JS bundle to a minimum size

// Layouts
import AuthLayout from "./layouts/Auth";
import DashboardLayout from "./layouts/Dashboard";
import LandingLayout from "./layouts/Landing";


// Guards
import AuthGuard from "./components/guards/AuthGuard";

// Landing
import Landing from "./pages/landing/Landing";

// Dashboards
import Default from "./pages/dashboards/Default";
import Analytics from "./pages/dashboards/Analytics";

 
// Auth
import Page500 from "./pages/auth/Page500";
import Page404 from "./pages/auth/Page404";
import SignIn from "./pages/auth/SignIn";
import SignUp from "./pages/auth/SignUp";
import ResetPassword from "./pages/auth/ResetPassword";



import CampaignDetails from './pages/dashboards/CampaignDetails'

// Protected routes
import ProtectedPage from "./pages/protected/ProtectedPage";
import CustomerAcquisitionDetails from "./pages/dashboards/CustomerAcquisitionDetails";
import CustomerRetentionDetails from "./pages/dashboards/CustomerRetentionDetails";
import CustomerLoyality from "./pages/dashboards/CustomerLoyalty";
import CustomerLifetimeValidation from "./pages/cltv"
import Churn from "./pages/dashboards/Churn";
import CustomerJourney from "./pages/Customer-Journey";
import RulesEngine from "./pages/Rules-Engine";
import NextBestAction from "./pages/nba";
import Sales from "./pages/sales";
import Sainsbury  from "./pages/sainsbury";

const routes = [
  {
    path: "/",
    element: <LandingLayout />,
    children: [
      {
        path: "",
        element: <Landing />,
      },
    ],
  },
  {
    path: "dashboard",
    element: <DashboardLayout />,
    children: [
      {
        path: "default",
        element: <Default />,
      },
      {
        path: "analytics",
        element: <Analytics />,
      },
      {
        path: "churn",
        element: <Churn />,
      },
      {
        path: "campaign-details",
        element: <CampaignDetails />,
      },
      {
        path: "cltv",
        element: <CustomerLifetimeValidation />
      },
      {
        path: "customer-acquisition",
        element: <CustomerAcquisitionDetails />,
      },
      {
        path: "customer-loyality",
        element: <CustomerLoyality />,
      },
      {
        path: "customer-retention",
        element: <CustomerRetentionDetails />,
      },
      {
        path: "customer-journey",
        element: <CustomerJourney />
      },
      {
        path: "rules-engine",
        element: <RulesEngine />
      },
      {
        path: "nba",
        element: <NextBestAction />
      },
      {
        path: "sales",
        element: <Sales />
      },
      {
        path: "sainsbury",
        element: <Sainsbury />
      }
    ],
  },
  {
    path: "auth",
    element: <AuthLayout />,
    children: [
      {
        path: "sign-in",
        element: <SignIn />,
      },
      {
        path: "sign-up",
        element: <SignUp />,
      },
      {
        path: "reset-password",
        element: <ResetPassword />,
      },
      {
        path: "404",
        element: <Page404 />,
      },
      {
        path: "500",
        element: <Page500 />,
      },
    ],
  },
  {
    path: "SignIn",
    element: <AuthLayout />,
    children: [
      {
        path: "",
        element: <SignIn />,
      },
      {
        
        path: "sign-up",
        element: <SignUp />,
      },
      {
        path: "reset-password",
        element: <ResetPassword />,
      },
      {
        path: "404",
        element: <Page404 />,
      },
      {
        path: "500",
        element: <Page500 />,
      },
    ],
  },
  {
    path: "private",
    element: (
      <AuthGuard>
        <DashboardLayout />
      </AuthGuard>
    ),
    children: [
      {
        path: "",
        element: <ProtectedPage />,
      },
    ],
  },
  {
    path: "*",
    element: <AuthLayout />,
    children: [
      {
        path: "*",
        element: <Page404 />,
      },
    ],
  },
];

export default routes;


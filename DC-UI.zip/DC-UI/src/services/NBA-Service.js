import axios from "axios";
import { devEnvConfig } from "../config";


export const getNBADataForDropDown = () => {
     
    return axios
      .get(devEnvConfig.pythonServerURL+"tepezza_next_best_action_data/")
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getNBADataForSelectedCustomerID = (customerID) => {
     

    return axios
      .get(devEnvConfig.pythonServerURL+"tepezza_next_best_action_data_by_customerId", { params: { userId: customerID }})
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getNBADataList = () => {
     

    return axios
      .get(devEnvConfig.pythonServerURL+"return_tepezza_next_best_action_data_list/")
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}



export const saveNBAConfigRulesForm = (data) => {
     

  return axios
    .post(devEnvConfig.nodeServerURL+ "api/v1/user/nba-rules-config",
      data,
      {
        headers: {
        'Content-Type': 'application/json'
        }
      }
    )
    .then((response) => {
              return response;
    })
    .catch((error) => {
      console.error("Error fetching data: ", error);
                  return error;

    })

}



export const getNBAConfigRulesFormData = () => {
     

  return axios
    .get(devEnvConfig.nodeServerURL+"api/v1/user/nba-rules-config",
      {
        headers: {
        'Content-Type': 'application/json'
        }
      }
    )
    .then((response) => {
              return response;
    })
    .catch((error) => {
      console.error("Error fetching data: ", error);
                  return error;

    })

}
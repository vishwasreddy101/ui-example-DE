import axios from "axios";
import { devEnvConfig } from "../config";


export const filterSainsburyData = (filterData) => {
    return axios
      .post(devEnvConfig.pythonServerURL+"sainsbury/",filterData,
      {
        headers: {
        'Content-Type': 'application/json'
        }
      })
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


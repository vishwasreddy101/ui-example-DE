import axios from "axios";
import randomString from "random-string";
import { devEnvConfig } from "../config";


export const getTDBankFileSizeService = () => {
     
  
    // http://localhost:8080/data_stored_size/
    // http://localhost:3000/employees/1
    return axios
      .post(devEnvConfig.pythonServerURL+"data_stored_size/", {
        client_id: "td-bank",
      })
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getChurnDataById = (userId) => {
     
    return axios
      .get(devEnvConfig.pythonServerURL+"csv_data_for_churn_by_userid", { params: { userId: userId } })
        .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}

export const getCltvDataById = (userId) => {
     
    return axios
      .get(devEnvConfig.pythonServerURL+"csv_data_for_cltv_by_userid", { params: { userId: userId } })
        .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getCSVDataByGender = () => {
     
    return axios
        .get(devEnvConfig.pythonServerURL+"csv_data_by_gender/")
        .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}

export const getCustomerJourneyTableData = (selectedOption) => {
     
  return axios
      .get("http://localhost:3000/customerJourneyData?customer_id=" + selectedOption)
      .then((response) => {
              return response;
    })
    .catch((error) => {
      console.error("Error fetching data: ", error);
                  return error;

    })

}

export const GetOverAllDagRunStatus = (dagId , dagRunId) => {
    
  const usernamePasswordBuffer = Buffer.from('admin'.concat(':').concat('airflow'));
  const base64data = usernamePasswordBuffer.toString('base64');
  return axios(
    "http://20.110.154.45:8080/api/v1/dags/"+ dagId + "/dagRuns/"+ dagRunId,
   {
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Basic ${base64data}`
    },
  method: "get",
}).then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}

export const GetCurrentRunningDagTaskInstanceStatus = (dagId , dagRunId) => {

  const usernamePasswordBuffer = Buffer.from('admin'.concat(':').concat('airflow'));
  const base64data = usernamePasswordBuffer.toString('base64');
  return axios(
    "http://20.110.154.45:8080/api/v1/dags/"+ dagId + "/dagRuns/"+ dagRunId + "/taskInstances",      // http://localhost:3000/getDagTaskList // http://20.110.154.45:8080/api/v1/dags/"+ dagId + "/dagRuns/"+ dagRunId + "/taskInstances
   {
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Basic ${base64data}`
    },
  method: "get",
    }).then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const RunningDagModel = (dagId) => {
  

  var dagRunId = dagId + "_" + randomString({
                        length: 5,
                        numeric: true,
                        letters: false,
                        special: false,
});
 
  const usernamePasswordBuffer = Buffer.from('admin'.concat(':').concat('airflow'));
  const base64data = usernamePasswordBuffer.toString('base64');

  return axios("http://20.110.154.45:8080/api/v1/dags/" + dagId + "/dagRuns", // http://localhost:3000/runDagModel // http://20.110.154.45:8080/api/v1/dags/" + dagId + "/dagRuns
    { 
    headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Basic ${base64data}`

      },
    method: "post",
    data: {
      dag_run_id: dagRunId, // This is the body part      
  }
  })
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getDropDownCustomerList = () => {
     
    return axios
        .get(devEnvConfig.pythonServerURL+"dropdown_data_of_customers/")
        .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}


export const getCustomerDataById = (userId) => {
     
    return axios
        .get(devEnvConfig.pythonServerURL+"csv_data_by_customer_id",{ params: { userId: userId } })
        .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}

export const getCSVDataByGenderSegment = () => {
     
  return axios
    .get(devEnvConfig.pythonServerURL+"csv_data_by_gender_segment/")
    .then((response) => {
      return response;
    })
    .catch((error) => {
      console.error("Error fetching data: ", error);
      return error;

    })

}




    
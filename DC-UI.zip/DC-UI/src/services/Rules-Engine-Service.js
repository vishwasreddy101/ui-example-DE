import axios from "axios";
import { devEnvConfig } from "../config";

export const getFilteredHCPData = (filterFormObject) => {
     
  
    return axios
      .post(devEnvConfig.pythonServerURL+"filterHCPData/", {
        filterFormObject
      })
      .then((response) => {
                return response;
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
                    return error;

      })

}